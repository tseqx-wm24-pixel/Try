import React, { useCallback, useEffect, useRef, useState } from "react";
import { MapWorkspace } from "./MapWorkspace";
import {
  Coordinate,
  DrawMode,
  ExecutionState,
  RouteCandidate,
  TaskItem,
  TelemetryFrame,
} from "./types/api";

const API_BASE =
  (import.meta as any).env?.VITE_API_BASE_URL || "http://localhost:8000";
const OPERATOR_TOKEN =
  (import.meta as any).env?.VITE_OPERATOR_TOKEN || "dev-operator-token";

interface CampusPreset {
  id: string;
  name: string;
  center: Coordinate;
  boundary: Coordinate[];
  startLocation: Coordinate;
  disposalLocation: Coordinate;
  sampleBins: Coordinate[];
}

const CAMPUS_PRESETS: CampusPreset[] = [
  {
    id: "plaza",
    name: "Planetarium Central Plaza",
    center: { lat: 3.13918, lon: 101.6871 },
    boundary: [
      { lat: 3.13902, lon: 101.68692 },
      { lat: 3.13902, lon: 101.68728 },
      { lat: 3.13934, lon: 101.68728 },
      { lat: 3.13934, lon: 101.68692 },
    ],
    startLocation: { lat: 3.139, lon: 101.6869 },
    disposalLocation: { lat: 3.13886, lon: 101.68682 },
    sampleBins: [
      { lat: 3.1393, lon: 101.68724 },
      { lat: 3.13906, lon: 101.68724 },
    ],
  },
  {
    id: "west-lot",
    name: "West Car Park & Service Bay",
    center: { lat: 3.13905, lon: 101.68634 },
    boundary: [
      { lat: 3.13888, lon: 101.68606 },
      { lat: 3.13888, lon: 101.6866 },
      { lat: 3.13922, lon: 101.6866 },
      { lat: 3.13922, lon: 101.68606 },
    ],
    startLocation: { lat: 3.13886, lon: 101.68604 },
    disposalLocation: { lat: 3.13878, lon: 101.68598 },
    sampleBins: [
      { lat: 3.13918, lon: 101.68655 },
      { lat: 3.13892, lon: 101.68652 },
    ],
  },
  {
    id: "north-lawn",
    name: "North Academic Walk",
    center: { lat: 3.13968, lon: 101.68662 },
    boundary: [
      { lat: 3.1395, lon: 101.68638 },
      { lat: 3.1395, lon: 101.68686 },
      { lat: 3.13986, lon: 101.68686 },
      { lat: 3.13986, lon: 101.68638 },
    ],
    startLocation: { lat: 3.13948, lon: 101.68635 },
    disposalLocation: { lat: 3.1394, lon: 101.6863 },
    sampleBins: [{ lat: 3.13982, lon: 101.6868 }],
  },
];

type ZoneClassification =
  | "STANDARD_SWEEP"
  | "SWEEP_AND_BINS"
  | "BIN_PICKUP_ONLY"
  | "BULKY_WASTE";

interface YoloDetectionBox {
  id: string;
  label: string;
  category: "plastic" | "paper" | "bin" | "bulky" | "obstacle";
  confidence: number;
  x: number; // percentage 10..75
  y: number; // percentage 25..70
  w: number; // percentage 14..26
  h: number; // percentage 16..30
  color: string;
}

interface UrgentWasteAlert {
  id: string;
  title: string;
  description: string;
  weightKg: number;
  locationLabel: string;
  location: Coordinate;
  timestamp: string;
}

function toLocalMeters(c: Coordinate, origin: Coordinate): [number, number] {
  const latRad = (origin.lat * Math.PI) / 180.0;
  return [
    (c.lon - origin.lon) * 111320.0 * Math.cos(latRad),
    (c.lat - origin.lat) * 110540.0,
  ];
}

function fromLocalMeters(
  x: number,
  y: number,
  origin: Coordinate
): Coordinate {
  const latRad = (origin.lat * Math.PI) / 180.0;
  return {
    lat: Number((origin.lat + y / 110540.0).toFixed(7)),
    lon: Number((origin.lon + x / (111320.0 * Math.cos(latRad))).toFixed(7)),
  };
}

function distMeters(a: Coordinate, b: Coordinate): number {
  const [dx, dy] = toLocalMeters(b, a);
  return Math.hypot(dx, dy);
}

function pointInPolygonLocal(
  px: number,
  py: number,
  polyPts: [number, number][]
): boolean {
  let inside = false;
  for (let i = 0, j = polyPts.length - 1; i < polyPts.length; j = i++) {
    const [xi, yi] = polyPts[i];
    const [xj, yj] = polyPts[j];
    const intersect =
      yi > py !== yj > py &&
      px < ((xj - xi) * (py - yi)) / (yj - yi + 1e-12) + xi;
    if (intersect) inside = !inside;
  }
  return inside;
}

function polygonAreaM2(vertices: Coordinate[]): number {
  if (vertices.length < 3) return 0;
  const origin = vertices[0];
  const pts = vertices.map((v) => toLocalMeters(v, origin));
  let area = 0;
  for (let i = 0; i < pts.length; i++) {
    const [x1, y1] = pts[i];
    const [x2, y2] = pts[(i + 1) % pts.length];
    area += x1 * y2 - x2 * y1;
  }
  return Math.abs(area) / 2.0;
}

function buildLocalFallbackRoute(params: {
  jobId: string;
  version: number;
  machineId: string;
  boundary: Coordinate[];
  dynamicObstacles: { id: string; name: string; vertices: Coordinate[] }[];
  tasks: TaskItem[];
  startLocation: Coordinate;
  disposalLocation: Coordinate;
  retainedCompletedSegments: RouteCandidate["segments"];
  replanReason: string;
}): RouteCandidate {
  const {
    jobId,
    version,
    machineId,
    boundary,
    dynamicObstacles,
    tasks,
    startLocation,
    disposalLocation,
    retainedCompletedSegments,
    replanReason,
  } = params;

  const segments: RouteCandidate["segments"] = retainedCompletedSegments.map(
    (s) => ({ ...s, completed: true })
  );

  const overlap = 0.14;
  const angle = 0;

  if (boundary.length >= 3) {
    const origin = boundary[0];
    const polyLocal = boundary.map((v) => toLocalMeters(v, origin));
    const obstaclePolysLocal = dynamicObstacles.map((obs) =>
      obs.vertices.map((v) => toLocalMeters(v, origin))
    );

    const xs = polyLocal.map((p) => p[0]);
    const ys = polyLocal.map((p) => p[1]);
    const minX = Math.min(...xs);
    const maxX = Math.max(...xs);
    const minY = Math.min(...ys);
    const maxY = Math.max(...ys);

    const step = 1.6 * (1 - overlap);
    let y = minY + 0.8;
    let ltr = true;
    let prevEnd: Coordinate | null =
      segments.length > 0
        ? segments[segments.length - 1].waypoints[
            segments[segments.length - 1].waypoints.length - 1
          ]
        : null;
    let segCounter = segments.length + 1;

    while (y <= maxY - 0.8) {
      const samples = 36;
      let currentRun: Coordinate[] = [];
      const runs: [Coordinate, Coordinate][] = [];

      for (let s = 0; s <= samples; s++) {
        const frac = ltr ? s / samples : 1 - s / samples;
        const wx = minX + 0.8 + frac * Math.max(1, maxX - minX - 1.6);
        const wy = y;
        const inOuter = pointInPolygonLocal(wx, wy, polyLocal);
        const inObs = obstaclePolysLocal.some((op) =>
          pointInPolygonLocal(wx, wy, op)
        );
        if (inOuter && !inObs) {
          currentRun.push(fromLocalMeters(wx, wy, origin));
        } else {
          if (currentRun.length >= 2) {
            runs.push([currentRun[0], currentRun[currentRun.length - 1]]);
          }
          currentRun = [];
        }
      }
      if (currentRun.length >= 2) {
        runs.push([currentRun[0], currentRun[currentRun.length - 1]]);
      }

      for (const r of runs) {
        const d = distMeters(r[0], r[1]);
        if (d < 1.2) continue;
        if (prevEnd) {
          const td = distMeters(prevEnd, r[0]);
          segments.push({
            segment_id: `turn-${version}-${segCounter++}`,
            segment_type: "TURN_CONNECTOR",
            waypoints: [prevEnd, r[0]],
            distance_m: Number(td.toFixed(1)),
            estimated_duration_sec: Number((td / 0.9).toFixed(1)),
            swath_width_m: 1.6,
            provenance: "PLANNED",
            completed: false,
          });
        }
        segments.push({
          segment_id: `swath-${version}-${segCounter++}`,
          segment_type: "SWEEP_SWATH",
          waypoints: [r[0], r[1]],
          distance_m: Number(d.toFixed(1)),
          estimated_duration_sec: Number((d / 1.1).toFixed(1)),
          swath_width_m: 1.6,
          provenance: "PLANNED",
          completed: false,
        });
        prevEnd = r[1];
      }
      ltr = !ltr;
      y += step;
    }
  }

  let currPos =
    segments.length > 0
      ? segments[segments.length - 1].waypoints[
          segments[segments.length - 1].waypoints.length - 1
        ]
      : startLocation;

  let taskIdx = 1;
  for (const t of tasks) {
    if (t.completed) continue;
    const d = distMeters(currPos, t.location);
    segments.push({
      segment_id: `transit-task-${version}-${taskIdx}`,
      segment_type: "TRANSIT",
      waypoints: [currPos, t.location],
      distance_m: Number(d.toFixed(1)),
      estimated_duration_sec: Number((d / 1.5).toFixed(1)),
      swath_width_m: 0,
      target_task_id: t.task_id,
      provenance: "PLANNED",
      completed: false,
    });
    segments.push({
      segment_id: `stop-task-${version}-${taskIdx}`,
      segment_type: "COLLECTION_STOP",
      waypoints: [t.location, t.location],
      distance_m: 0,
      estimated_duration_sec: t.service_duration_sec || 45,
      swath_width_m: 0,
      target_task_id: t.task_id,
      provenance: "PLANNED",
      completed: false,
    });
    currPos = t.location;
    taskIdx++;
  }

  if (segments.length > 0) {
    const rd = distMeters(currPos, disposalLocation);
    segments.push({
      segment_id: `return-${version}`,
      segment_type: "RETURN_TO_BASE",
      waypoints: [currPos, disposalLocation],
      distance_m: Number(rd.toFixed(1)),
      estimated_duration_sec: Number((rd / 1.5).toFixed(1)),
      swath_width_m: 0,
      provenance: "PLANNED",
      completed: false,
    });
  }

  const sweepDist = segments
    .filter((s) => s.segment_type === "SWEEP_SWATH")
    .reduce((acc, s) => acc + s.distance_m, 0);
  const transitDist = segments
    .filter((s) => s.segment_type !== "SWEEP_SWATH")
    .reduce((acc, s) => acc + s.distance_m, 0);
  const totalDist = sweepDist + transitDist;
  const totalDurMin =
    segments.reduce((acc, s) => acc + s.estimated_duration_sec, 0) / 60.0;
  const areaM2 = Math.max(100, Math.round(polygonAreaM2(boundary)));
  const covPct = boundary.length >= 3 ? 97.4 : 100.0;
  const remBatt = Number(
    Math.max(24, 96 - (totalDist / 1000) * 6.5).toFixed(1)
  );

  const taskMode =
    boundary.length >= 3 && tasks.length > 0
      ? "HYBRID"
      : tasks.some((t) => t.task_type === "OVERSIZED_RUBBISH")
      ? "OVERSIZED_RUBBISH"
      : tasks.length > 0
      ? "RUBBISH_COLLECTION"
      : "AREA_SWEEP";

  return {
    route_id: `route-v${version}`,
    job_id: jobId,
    route_version: version,
    plan_epoch: version,
    machine_id: machineId,
    status: "EXECUTING",
    task_mode: taskMode,
    routing_provenance: "PLANNED",
    mission_elapsed_min: 0,
    origin: startLocation,
    disposal_depot: disposalLocation,
    operating_boundary: boundary.length >= 3 ? { vertices: boundary } : null,
    exclusion_zones: dynamicObstacles.map((o) => ({
      zone_id: o.id,
      name: o.name,
      reason: "Live Obstacle",
      polygon: { vertices: o.vertices },
    })),
    tasks,
    task_schedule: [],
    skipped_tasks: [],
    route_safety_issues: [],
    candidate_rationale: [replanReason],
    deduplicated_task_ids: [],
    segments,
    unreachable_sections: [],
    target_area_m2: areaM2,
    covered_area_m2: Math.round((areaM2 * covPct) / 100),
    repeated_area_m2: Math.round(areaM2 * 0.04),
    missed_area_m2: Math.round(areaM2 * ((100 - covPct) / 100)),
    sweep_angle_deg: angle,
    overlap_ratio: overlap,
    total_distance_m: Number(totalDist.toFixed(1)),
    sweep_distance_m: Number(sweepDist.toFixed(1)),
    transit_distance_m: Number(transitDist.toFixed(1)),
    estimated_duration_minutes: Number(totalDurMin.toFixed(1)),
    estimated_energy_kwh: Number(((totalDist / 1000) * 1.1).toFixed(2)),
    estimated_remaining_battery_percent: remBatt,
    payload_utilization_percent: Math.min(90, 18 + tasks.length * 18),
    disposal_trips: 1,
    replan_reason: replanReason,
    kpi_evaluation: {
      evaluation_id: `eval-${version}`,
      route_version: version,
      policy_version: "v1.2.0",
      passed: true,
      score: 96.4,
      metrics: {},
      failed_constraints: [],
      recommended_adjustments: [],
      requires_human_review: false,
    },
  };
}

export const App: React.FC = () => {
  const [jobId] = useState<string>("campus-clean-job-01");

  // Left Sidebar Main View Switcher: "REALTIME" vs "ROUTE" (Matches user sketch)
  const [activeNav, setActiveNav] = useState<"REALTIME" | "ROUTE">("REALTIME");

  // Top-right Machine ID Selector
  const [machineId, setMachineId] = useState<string>("sweeper-alpha-01");

  // Map & Route State (Clean on startup — no unprompted routes)
  const [drawMode, setDrawMode] = useState<DrawMode>("BOX_AREA");
  const [mapCenter, setMapCenter] = useState<Coordinate>({
    lat: 3.13918,
    lon: 101.6871,
  });
  const [startLocation, setStartLocation] = useState<Coordinate>({
    lat: 3.139,
    lon: 101.6869,
  });
  const [disposalLocation, setDisposalLocation] = useState<Coordinate>({
    lat: 3.13886,
    lon: 101.68682,
  });
  const [boundary, setBoundary] = useState<Coordinate[]>([]);
  const [boxCornerStart, setBoxCornerStart] = useState<Coordinate | null>(null);
  const [obstacleCornerStart, setObstacleCornerStart] =
    useState<Coordinate | null>(null);
  const [dynamicObstacles, setDynamicObstacles] = useState<
    { id: string; name: string; vertices: Coordinate[] }[]
  >([]);
  const [tasks, setTasks] = useState<TaskItem[]>([]);
  const [selectedClassification, setSelectedClassification] =
    useState<ZoneClassification | null>(null);

  const [activeRoute, setActiveRoute] = useState<RouteCandidate | null>(null);
  const [executionState, setExecutionState] = useState<ExecutionState>("IDLE");
  const [livePosition, setLivePosition] = useState<Coordinate>({
    lat: 3.139,
    lon: 101.6869,
  });
  const [batteryPercent, setBatteryPercent] = useState<number>(96.0);
  const [statusBanner, setStatusBanner] = useState<string>(
    "Robot Standby — Switch to 'Route' to select an area on the map, or monitor YOLO live collection here."
  );

  // Waste Collected 2x2 Grid Counters (Bottom-Left of Real-time View)
  const [wasteStats, setWasteStats] = useState({
    plasticAndCans: 14,
    paperAndPackaging: 9,
    binsEmptied: 2,
    bulkyItems: 0,
    totalWeightKg: 18.4,
  });

  // Middle YOLO Screen State
  const [yoloBoxes, setYoloBoxes] = useState<YoloDetectionBox[]>([
    {
      id: "det-1",
      label: "Plastic Bottle",
      category: "plastic",
      confidence: 0.94,
      x: 22,
      y: 52,
      w: 16,
      h: 22,
      color: "#10b981",
    },
    {
      id: "det-2",
      label: "Cardboard Cup",
      category: "paper",
      confidence: 0.89,
      x: 58,
      y: 56,
      w: 15,
      h: 19,
      color: "#38bdf8",
    },
  ]);
  const [yoloFps, setYoloFps] = useState<number>(29.4);
  const [useWebcam, setUseWebcam] = useState<boolean>(false);
  const videoRef = useRef<HTMLVideoElement | null>(null);

  // Sudden Urgent Bulky/Heavy Waste Notification State
  const [urgentAlert, setUrgentAlert] = useState<UrgentWasteAlert | null>({
    id: "urgent-req-101",
    title: "🚨 Urgent Citizen Request: Bulky / Heavy Waste Collection",
    description:
      "Abandoned 3-Seater Sofa & Wooden Pallet (~85 kg) reported blocking Central Plaza East Walkway.",
    weightKg: 85,
    locationLabel: "Central Plaza East Curb (3.13926, 101.68722)",
    location: { lat: 3.13926, lon: 101.68722 },
    timestamp: "Just now",
  });

  const routeVersionRef = useRef<number>(0);
  const simTimerRef = useRef<number | null>(null);

  const stopSimulationTimer = useCallback(() => {
    if (simTimerRef.current !== null) {
      window.clearInterval(simTimerRef.current);
      simTimerRef.current = null;
    }
  }, []);

  useEffect(() => {
    return () => stopSimulationTimer();
  }, [stopSimulationTimer]);

  // Webcam toggle handler for middle YOLO screen
  useEffect(() => {
    let stream: MediaStream | null = null;
    if (useWebcam && videoRef.current) {
      navigator.mediaDevices
        ?.getUserMedia({ video: true })
        .then((s) => {
          stream = s;
          if (videoRef.current) {
            videoRef.current.srcObject = s;
          }
        })
        .catch(() => {
          setUseWebcam(false);
          setStatusBanner(
            "Webcam permission unavailable — using simulated Robot YOLO camera feed."
          );
        });
    }
    return () => {
      if (stream) {
        stream.getTracks().forEach((t) => t.stop());
      }
    };
  }, [useWebcam]);

  // Animate YOLO detections when robot is active or in real-time view
  useEffect(() => {
    const samplePool: Omit<YoloDetectionBox, "id">[] = [
      {
        label: "PET Plastic Bottle",
        category: "plastic",
        confidence: 0.95,
        x: 24,
        y: 54,
        w: 15,
        h: 22,
        color: "#10b981",
      },
      {
        label: "Aluminum Can",
        category: "plastic",
        confidence: 0.91,
        x: 62,
        y: 58,
        w: 14,
        h: 18,
        color: "#10b981",
      },
      {
        label: "Food Wrapper / Paper",
        category: "paper",
        confidence: 0.88,
        x: 42,
        y: 60,
        w: 16,
        h: 18,
        color: "#38bdf8",
      },
      {
        label: "Campus Rubbish Bin",
        category: "bin",
        confidence: 0.96,
        x: 70,
        y: 36,
        w: 18,
        h: 34,
        color: "#f59e0b",
      },
      {
        label: "Discarded Cardboard Box",
        category: "paper",
        confidence: 0.92,
        x: 18,
        y: 48,
        w: 20,
        h: 24,
        color: "#38bdf8",
      },
    ];

    const timer = window.setInterval(() => {
      setYoloFps(Number((28.2 + Math.random() * 2.4).toFixed(1)));
      const pick1 = samplePool[Math.floor(Math.random() * samplePool.length)];
      const pick2 = samplePool[Math.floor(Math.random() * samplePool.length)];
      const jitter = () => Math.round((Math.random() - 0.5) * 6);

      const nextBoxes: YoloDetectionBox[] = [
        {
          ...pick1,
          id: `yolo-${Date.now()}-1`,
          x: Math.max(10, Math.min(72, pick1.x + jitter())),
          y: Math.max(28, Math.min(68, pick1.y + jitter())),
          confidence: Number(
            Math.min(0.99, pick1.confidence + (Math.random() - 0.5) * 0.04).toFixed(2)
          ),
        },
      ];

      if (pick2.label !== pick1.label) {
        nextBoxes.push({
          ...pick2,
          id: `yolo-${Date.now()}-2`,
          x: Math.max(12, Math.min(74, pick2.x + jitter())),
          y: Math.max(28, Math.min(68, pick2.y + jitter())),
          confidence: Number(
            Math.min(0.99, pick2.confidence + (Math.random() - 0.5) * 0.04).toFixed(2)
          ),
        });
      }

      if (tasks.some((t) => t.task_type === "OVERSIZED_RUBBISH" && !t.completed)) {
        nextBoxes.push({
          id: `yolo-bulky-${Date.now()}`,
          label: "BULKY SOFA (85kg) — LIFT REQ",
          category: "bulky",
          confidence: 0.98,
          x: 34,
          y: 34,
          w: 32,
          h: 34,
          color: "#ef4444",
        });
      }

      setYoloBoxes(nextBoxes);

      // If executing a route, increment collected items naturally
      if (executionState === "EXECUTING") {
        setWasteStats((prev) => ({
          ...prev,
          plasticAndCans:
            prev.plasticAndCans + (Math.random() > 0.55 ? 1 : 0),
          paperAndPackaging:
            prev.paperAndPackaging + (Math.random() > 0.65 ? 1 : 0),
          totalWeightKg: Number((prev.totalWeightKg + 0.15).toFixed(1)),
        }));
      }
    }, 2200);

    return () => window.clearInterval(timer);
  }, [executionState, tasks]);

  const startLiveSimulation = useCallback(
    (route: RouteCandidate) => {
      stopSimulationTimer();
      setExecutionState("EXECUTING");

      simTimerRef.current = window.setInterval(() => {
        setActiveRoute((prev) => {
          if (!prev) return null;
          const nextIdx = prev.segments.findIndex((s) => !s.completed);
          if (nextIdx === -1) {
            stopSimulationTimer();
            setExecutionState("COMPLETED");
            setStatusBanner(
              "✅ Route cleaning & waste collection completed! All segments swept and bins emptied."
            );
            return { ...prev, status: "COMPLETED" };
          }

          const updatedSegments = prev.segments.map((s, idx) =>
            idx === nextIdx ? { ...s, completed: true } : s
          );
          const finishedSeg = updatedSegments[nextIdx];
          const lastWp =
            finishedSeg.waypoints[finishedSeg.waypoints.length - 1];
          if (lastWp) {
            setLivePosition(lastWp);
          }

          if (
            finishedSeg.segment_type === "COLLECTION_STOP" &&
            finishedSeg.target_task_id
          ) {
            setTasks((oldTasks) =>
              oldTasks.map((t) => {
                if (t.task_id === finishedSeg.target_task_id && !t.completed) {
                  const isBulky = t.task_type === "OVERSIZED_RUBBISH";
                  setWasteStats((ws) => ({
                    ...ws,
                    binsEmptied: isBulky ? ws.binsEmptied : ws.binsEmptied + 1,
                    bulkyItems: isBulky ? ws.bulkyItems + 1 : ws.bulkyItems,
                    totalWeightKg: Number(
                      (ws.totalWeightKg + (isBulky ? 85 : 6.5)).toFixed(1)
                    ),
                  }));
                  return { ...t, completed: true };
                }
                return t;
              })
            );
          }

          const doneCount = updatedSegments.filter((s) => s.completed).length;
          const totalCount = Math.max(1, updatedSegments.length);
          const spent =
            (doneCount / totalCount) *
            (96 - prev.estimated_remaining_battery_percent);
          setBatteryPercent(Number(Math.max(15, 96 - spent).toFixed(1)));

          return {
            ...prev,
            segments: updatedSegments,
          };
        });
      }, 320);
    },
    [stopSimulationTimer]
  );

  const triggerRoutePlan = useCallback(
    async (params: {
      nextBoundary: Coordinate[];
      nextObstacles: { id: string; name: string; vertices: Coordinate[] }[];
      nextTasks: TaskItem[];
      nextMachineId: string;
      reason: string;
      preserveCompleted: boolean;
    }) => {
      const {
        nextBoundary,
        nextObstacles,
        nextTasks,
        nextMachineId,
        reason,
        preserveCompleted,
      } = params;

      if (nextBoundary.length < 3 && nextTasks.length === 0) {
        return;
      }

      stopSimulationTimer();
      setExecutionState("PLANNING");
      setStatusBanner(`⏳ Planning optimal route (${reason})...`);

      const completedSegs =
        preserveCompleted && activeRoute
          ? activeRoute.segments.filter((s) => s.completed)
          : [];

      const nextVer = routeVersionRef.current + 1;
      routeVersionRef.current = nextVer;

      try {
        const res = await fetch(`${API_BASE}/api/routes/plan`, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${OPERATOR_TOKEN}`,
          },
          body: JSON.stringify({
            job_id: jobId,
            machine_id: nextMachineId,
            start_location: preserveCompleted ? livePosition : startLocation,
            disposal_location: disposalLocation,
            operating_boundary:
              nextBoundary.length >= 3 ? { vertices: nextBoundary } : null,
            exclusion_zones: nextObstacles.map((o) => ({
              zone_id: o.id,
              name: o.name,
              reason: "Live Obstacle",
              polygon: { vertices: o.vertices },
            })),
            tasks: nextTasks,
          }),
        });
        if (res.ok) {
          const backendCandidate: RouteCandidate = await res.json();
          if (completedSegs.length > 0) {
            backendCandidate.segments = [
              ...completedSegs,
              ...backendCandidate.segments,
            ];
          }
          setActiveRoute(backendCandidate);
          setStatusBanner(
            `🟢 Route v${backendCandidate.route_version} active — ${reason}`
          );
          startLiveSimulation(backendCandidate);
          return;
        }
      } catch {
        // Fallback to instant local planner if backend is offline
      }

      const fallback = buildLocalFallbackRoute({
        jobId,
        version: nextVer,
        machineId: nextMachineId,
        boundary: nextBoundary,
        dynamicObstacles: nextObstacles,
        tasks: nextTasks,
        startLocation: preserveCompleted ? livePosition : startLocation,
        disposalLocation,
        retainedCompletedSegments: completedSegs,
        replanReason: reason,
      });

      setActiveRoute(fallback);
      setStatusBanner(`🟢 Route v${fallback.route_version} active — ${reason}`);
      startLiveSimulation(fallback);
    },
    [
      activeRoute,
      disposalLocation,
      jobId,
      livePosition,
      startLiveSimulation,
      startLocation,
      stopSimulationTimer,
    ]
  );

  // Handle accepting the Urgent Bulky/Heavy Waste Notification
  const handleAcceptUrgentWaste = () => {
    if (!urgentAlert) return;
    const alertItem = urgentAlert;
    setUrgentAlert(null);

    const nextMachine = "heavy-utility-02";
    setMachineId(nextMachine);

    const nextBoundary =
      boundary.length >= 3 ? boundary : CAMPUS_PRESETS[0].boundary;
    if (boundary.length < 3) {
      setBoundary(nextBoundary);
    }

    const urgentTask: TaskItem = {
      task_id: `urgent-bulky-${Date.now().toString().slice(-3)}`,
      task_type: "OVERSIZED_RUBBISH",
      location: alertItem.location,
      priority: 10,
      service_duration_sec: 180,
      time_window_start_min: 0,
      time_window_end_min: 90,
      completed: false,
      rubbish_spec: {
        description: alertItem.description,
        is_oversized: true,
        estimated_weight_kg: alertItem.weightKg,
        estimated_volume_m3: 1.8,
        dimensions_uncertain: false,
        requires_heavy_lifter: true,
      },
    };

    const nextTasks = [...tasks, urgentTask];
    setTasks(nextTasks);
    setSelectedClassification("BULKY_WASTE");
    setMapCenter(alertItem.location);

    triggerRoutePlan({
      nextBoundary,
      nextObstacles: dynamicObstacles,
      nextTasks,
      nextMachineId: nextMachine,
      reason: `Urgent Bulky Waste Accepted (${alertItem.weightKg}kg) — Heavy Collector Assigned`,
      preserveCompleted: Boolean(activeRoute),
    });
  };

  // Trigger a new simulated Urgent Bulky Waste Request anytime for demo
  const handleSimulateNewUrgentRequest = () => {
    const spots = [
      {
        label: "Planetarium North Plaza Steps",
        coord: { lat: 3.13931, lon: 101.68715 },
        desc: "Discarded Office Sofa & Broken Metal Rack (~92 kg)",
        kg: 92,
      },
      {
        label: "West Car Park Loading Bay",
        coord: { lat: 3.13912, lon: 101.68648 },
        desc: "Heavy Renovation Timber & Mattress (~110 kg)",
        kg: 110,
      },
    ];
    const pick = spots[Math.floor(Math.random() * spots.length)];
    setUrgentAlert({
      id: `urgent-${Date.now()}`,
      title: "🚨 Urgent Citizen Request: Bulky / Heavy Waste Collection",
      description: `${pick.desc} reported at ${pick.label}. Requires Heavy Collector with hydraulic lifter.`,
      weightKg: pick.kg,
      locationLabel: `${pick.label} (${pick.coord.lat.toFixed(5)}, ${pick.coord.lon.toFixed(5)})`,
      location: pick.coord,
      timestamp: new Date().toLocaleTimeString(),
    });
  };

  // Classify zone & auto-start route
  const handleClassifyZone = (classification: ZoneClassification) => {
    const activeBoundary =
      boundary.length >= 3 ? boundary : CAMPUS_PRESETS[0].boundary;
    if (boundary.length < 3) {
      setBoundary(activeBoundary);
    }

    setSelectedClassification(classification);
    let nextMachine = machineId;
    let nextTasks: TaskItem[] = [];

    const cLat =
      activeBoundary.reduce((s, p) => s + p.lat, 0) / activeBoundary.length;
    const cLon =
      activeBoundary.reduce((s, p) => s + p.lon, 0) / activeBoundary.length;

    if (classification === "STANDARD_SWEEP") {
      nextTasks = [];
    } else if (classification === "SWEEP_AND_BINS") {
      nextTasks = [
        {
          task_id: "bin-1",
          task_type: "RUBBISH_COLLECTION",
          location: { lat: cLat + 0.00011, lon: cLon + 0.00012 },
          priority: 8,
          service_duration_sec: 45,
          time_window_start_min: 0,
          time_window_end_min: 90,
          completed: false,
        },
        {
          task_id: "bin-2",
          task_type: "RUBBISH_COLLECTION",
          location: { lat: cLat - 0.0001, lon: cLon + 0.00012 },
          priority: 7,
          service_duration_sec: 45,
          time_window_start_min: 0,
          time_window_end_min: 90,
          completed: false,
        },
      ];
    } else if (classification === "BIN_PICKUP_ONLY") {
      nextTasks = [
        {
          task_id: "bin-pickup-1",
          task_type: "RUBBISH_COLLECTION",
          location: { lat: cLat + 0.0001, lon: cLon - 0.0001 },
          priority: 9,
          service_duration_sec: 45,
          time_window_start_min: 0,
          time_window_end_min: 90,
          completed: false,
        },
        {
          task_id: "bin-pickup-2",
          task_type: "RUBBISH_COLLECTION",
          location: { lat: cLat - 0.00009, lon: cLon + 0.00011 },
          priority: 8,
          service_duration_sec: 45,
          time_window_start_min: 0,
          time_window_end_min: 90,
          completed: false,
        },
      ];
    } else if (classification === "BULKY_WASTE") {
      nextMachine = "heavy-utility-02";
      setMachineId("heavy-utility-02");
      nextTasks = [
        {
          task_id: "bulky-waste-1",
          task_type: "OVERSIZED_RUBBISH",
          location: { lat: cLat + 0.00006, lon: cLon + 0.00007 },
          priority: 10,
          service_duration_sec: 180,
          time_window_start_min: 0,
          time_window_end_min: 90,
          completed: false,
          rubbish_spec: {
            description: "Bulky discarded furniture (~80kg)",
            is_oversized: true,
            estimated_weight_kg: 80,
            estimated_volume_m3: 1.6,
            dimensions_uncertain: false,
            requires_heavy_lifter: true,
          },
        },
      ];
    }

    setTasks(nextTasks);
    setDrawMode("INSTANT_OBSTACLE");

    const effectiveBoundary =
      classification === "BIN_PICKUP_ONLY" ? [] : activeBoundary;

    triggerRoutePlan({
      nextBoundary: effectiveBoundary,
      nextObstacles: dynamicObstacles,
      nextTasks,
      nextMachineId: nextMachine,
      reason: `Classified zone as ${classification.replace(/_/g, " ")}`,
      preserveCompleted: false,
    });
  };

  // Map Callbacks
  const handleSelectBoxArea = (boxVertices: Coordinate[]) => {
    setBoundary(boxVertices);
    setDynamicObstacles([]);
    setTasks([]);
    setStartLocation(boxVertices[0]);
    setStatusBanner(
      "Area selected on map! Now click one of the 4 Zone Type buttons above the map to auto-generate the route."
    );
  };

  const handleAddVertex = (coord: Coordinate) => {
    if (drawMode === "BOUNDARY") {
      setBoundary((prev) => [...prev, coord]);
    } else if (drawMode === "START") {
      setStartLocation(coord);
      setLivePosition(coord);
    } else if (drawMode === "DEPOT") {
      setDisposalLocation(coord);
    }
  };

  const handleDropInstantObstacle = (obsVertices: Coordinate[]) => {
    const newObs = {
      id: `obs-${Date.now()}`,
      name: `Obstacle #${dynamicObstacles.length + 1}`,
      vertices: obsVertices,
    };
    const nextObs = [...dynamicObstacles, newObs];
    setDynamicObstacles(nextObs);

    if (activeRoute) {
      triggerRoutePlan({
        nextBoundary: boundary,
        nextObstacles: nextObs,
        nextTasks: tasks,
        nextMachineId: machineId,
        reason: `Obstacle detected on path — Auto-replanned around ${newObs.name}`,
        preserveCompleted: true,
      });
    }
  };

  const handleAddTaskOnMap = (
    coord: Coordinate,
    isOversized: boolean,
    isEventWaste?: boolean
  ) => {
    const nextMachine =
      isOversized || isEventWaste ? "heavy-utility-02" : machineId;
    if (nextMachine !== machineId) {
      setMachineId(nextMachine);
    }
    const newTask: TaskItem = {
      task_id:
        isOversized || isEventWaste
          ? `bulky-${tasks.length + 1}`
          : `bin-${tasks.length + 1}`,
      task_type:
        isOversized || isEventWaste
          ? "OVERSIZED_RUBBISH"
          : "RUBBISH_COLLECTION",
      location: coord,
      priority: isOversized || isEventWaste ? 10 : 8,
      service_duration_sec: isOversized || isEventWaste ? 180 : 45,
      time_window_start_min: 0,
      time_window_end_min: 90,
      completed: false,
    };
    const nextTasks = [...tasks, newTask];
    setTasks(nextTasks);

    if (activeRoute || boundary.length >= 3) {
      triggerRoutePlan({
        nextBoundary: boundary,
        nextObstacles: dynamicObstacles,
        nextTasks,
        nextMachineId: nextMachine,
        reason: `Added ${newTask.task_id} on map — Route auto-updated`,
        preserveCompleted: true,
      });
    }
  };

  const handleMapClick = (coord: Coordinate) => {
    if (drawMode === "BOX_AREA") {
      if (!boxCornerStart) {
        setBoxCornerStart(coord);
        setStatusBanner("Select the opposite corner to finish the cleaning area.");
        return;
      }
      const selectedBox = [
        boxCornerStart,
        { lat: boxCornerStart.lat, lon: coord.lon },
        coord,
        { lat: coord.lat, lon: boxCornerStart.lon },
      ];
      setBoxCornerStart(null);
      handleSelectBoxArea(selectedBox);
      return;
    }

    if (drawMode === "INSTANT_OBSTACLE" || drawMode === "OBSTACLE") {
      if (!obstacleCornerStart) {
        setObstacleCornerStart(coord);
        setStatusBanner("Select the opposite corner to mark the blocked area.");
        return;
      }
      const obstacleBox = [
        obstacleCornerStart,
        { lat: obstacleCornerStart.lat, lon: coord.lon },
        coord,
        { lat: coord.lat, lon: obstacleCornerStart.lon },
      ];
      setObstacleCornerStart(null);
      handleDropInstantObstacle(obstacleBox);
      return;
    }

    if (drawMode === "TASK") {
      handleAddTaskOnMap(coord, false);
      return;
    }
    if (drawMode === "OVERSIZED") {
      handleAddTaskOnMap(coord, true);
      return;
    }
    if (drawMode === "EVENT_WASTE") {
      handleAddTaskOnMap(coord, true, true);
      return;
    }
    handleAddVertex(coord);
  };

  const handleClearMap = () => {
    stopSimulationTimer();
    setBoundary([]);
    setBoxCornerStart(null);
    setObstacleCornerStart(null);
    setDynamicObstacles([]);
    setTasks([]);
    setActiveRoute(null);
    setSelectedClassification(null);
    setExecutionState("IDLE");
    setDrawMode("BOX_AREA");
    setStatusBanner("Map cleared — Draw a box on the map to select a new cleaning area.");
  };

  // Computed metrics for Bottom-Right panel ("Machine condition", "Battery", "Route : xx km")
  const totalRouteKm = activeRoute
    ? (activeRoute.total_distance_m / 1000).toFixed(2)
    : "0.00";
  const completedSegCount = activeRoute
    ? activeRoute.segments.filter((s) => s.completed).length
    : 0;
  const totalSegCount = activeRoute ? activeRoute.segments.length : 0;
  const routeProgressPct =
    totalSegCount > 0 ? Math.round((completedSegCount / totalSegCount) * 100) : 0;

  const machineConditionText =
    executionState === "EMERGENCY_STOP"
      ? "🛑 EMERGENCY STOP ENGAGED"
      : executionState === "EXECUTING"
      ? "🟢 Optimal — Autonomous Sweeping & YOLO Active"
      : executionState === "PAUSED"
      ? "⏸️ Paused — Awaiting Resume"
      : executionState === "COMPLETED"
      ? "✅ Mission Complete — Ready at Depot"
      : "⚪ Standby — All Sensors Nominal";

  const latestTelemetryFrame: TelemetryFrame | null = activeRoute
    ? {
        telemetry_id: "live-frame",
        machine_id: machineId,
        route_id: activeRoute.route_id,
        mission_elapsed_min: 0,
        position: livePosition,
        speed_mps: executionState === "EXECUTING" ? 1.2 : 0,
        battery_percent: batteryPercent,
        payload_kg: wasteStats.totalWeightKg,
        payload_volume_m3: 0.4,
        route_deviation_m: 0.1,
        provenance: "SIMULATED",
      }
    : null;

  return (
    <div className="wireframe-shell">
      {/* LEFT SIDE PANEL: Switch between Real-time (Robot Collecting + YOLO) and Route Automation */}
      <aside className="left-nav-sidebar">
        <div className="brand-header">
          <div className="brand-logo">🤖 AARPES</div>
          <div className="brand-subtitle">Autonomous Waste &amp; Route AI</div>
        </div>

        <div className="nav-section-label">VIEW SWITCHER</div>
        <button
          type="button"
          className={`nav-switch-btn ${activeNav === "REALTIME" ? "active" : ""}`}
          onClick={() => setActiveNav("REALTIME")}
        >
          <span className="nav-icon">🎥</span>
          <div className="nav-btn-text">
            <strong>Real-time</strong>
            <span>YOLO Vision &amp; Waste Collected</span>
          </div>
        </button>

        <button
          type="button"
          className={`nav-switch-btn ${activeNav === "ROUTE" ? "active" : ""}`}
          onClick={() => setActiveNav("ROUTE")}
        >
          <span className="nav-icon">🗺️</span>
          <div className="nav-btn-text">
            <strong>Route</strong>
            <span>Map Area &amp; Auto-Replan</span>
          </div>
        </button>

        {/* Urgent Request Trigger Button for Demo Convenience */}
        <div className="nav-section-label" style={{ marginTop: 18 }}>
          LIVE DISPATCH DEMO
        </div>
        <button
          type="button"
          className="urgent-trigger-btn"
          onClick={handleSimulateNewUrgentRequest}
        >
          🔔 Simulate Sudden Bulky Waste Request
        </button>

        {/* Sidebar Footer Quick Controls */}
        <div className="sidebar-footer-controls">
          <div className="mini-status-pill">
            <span className="dot" />
            <span>State: {executionState}</span>
          </div>

          {activeRoute && (
            <div style={{ display: "flex", gap: 6, marginTop: 8 }}>
              {executionState === "EXECUTING" ? (
                <button
                  type="button"
                  className="btn-secondary-sm"
                  onClick={() => {
                    stopSimulationTimer();
                    setExecutionState("PAUSED");
                  }}
                >
                  ⏸️ Pause
                </button>
              ) : (
                <button
                  type="button"
                  className="btn-primary-sm"
                  onClick={() => startLiveSimulation(activeRoute)}
                >
                  ▶️ Resume
                </button>
              )}
              <button
                type="button"
                className="btn-danger-sm"
                onClick={() => {
                  stopSimulationTimer();
                  setExecutionState(
                    executionState === "EMERGENCY_STOP"
                      ? "IDLE"
                      : "EMERGENCY_STOP"
                  );
                }}
              >
                {executionState === "EMERGENCY_STOP"
                  ? "🔄 Reset E-Stop"
                  : "🛑 E-Stop"}
              </button>
            </div>
          )}
        </div>
      </aside>

      {/* MAIN STAGE (Matches Right Side of Sketch) */}
      <main className="main-stage">
        {/* TOP HEADER BAR: Status + Right-Aligned "Machine ID v" Dropdown */}
        <header className="stage-top-bar">
          <div className="stage-status-msg">{statusBanner}</div>

          <div className="machine-select-wrapper">
            <label htmlFor="machine-id-select" className="machine-id-label">
              Machine ID
            </label>
            <select
              id="machine-id-select"
              className="machine-id-dropdown"
              value={machineId}
              onChange={(e) => {
                const next = e.target.value;
                setMachineId(next);
                if (activeRoute) {
                  triggerRoutePlan({
                    nextBoundary: boundary,
                    nextObstacles: dynamicObstacles,
                    nextTasks: tasks,
                    nextMachineId: next,
                    reason: `Switched Machine ID to ${next}`,
                    preserveCompleted: true,
                  });
                }
              }}
            >
              <option value="sweeper-alpha-01">
                sweeper-alpha-01 (Compact Sweeper)
              </option>
              <option value="heavy-utility-02">
                heavy-utility-02 (Heavy Bulky Collector)
              </option>
            </select>
          </div>
        </header>

        {/* SUDDEN USER REQUEST OF URGENT BULKY / HEAVY WASTE COLLECTION NOTIFICATION */}
        {urgentAlert && (
          <div className="urgent-notification-banner">
            <div className="urgent-notif-left">
              <div className="urgent-badge">URGENT CITIZEN REQUEST</div>
              <div>
                <div className="urgent-title">{urgentAlert.title}</div>
                <div className="urgent-desc">
                  {urgentAlert.description} ·{" "}
                  <strong>📍 {urgentAlert.locationLabel}</strong>
                </div>
              </div>
            </div>
            <div className="urgent-notif-actions">
              <button
                type="button"
                className="btn-accept-urgent"
                onClick={handleAcceptUrgentWaste}
              >
                ⚡ Accept &amp; Auto-Replan Route
              </button>
              <button
                type="button"
                className="btn-dismiss-urgent"
                onClick={() => setUrgentAlert(null)}
              >
                Dismiss
              </button>
            </div>
          </div>
        )}

        {/* VIEW 1: REAL-TIME ROBOT COLLECTING + MIDDLE YOLO SCREEN */}
        {activeNav === "REALTIME" ? (
          <div className="realtime-content-grid">
            {/* MIDDLE SCREEN: YOLO REAL-TIME VISION */}
            <section className="yolo-screen-card">
              <div className="yolo-screen-header">
                <div className="yolo-title-group">
                  <span className="live-rec-dot" />
                  <strong>YOLO Real-Time Waste &amp; Obstacle Detection</strong>
                  <span className="yolo-meta-pill">
                    YOLOv8m · {yoloFps} FPS · {machineId}
                  </span>
                </div>
                <div className="yolo-controls">
                  <button
                    type="button"
                    className="yolo-action-btn"
                    onClick={() => {
                      setWasteStats((prev) => ({
                        ...prev,
                        plasticAndCans: prev.plasticAndCans + 1,
                        totalWeightKg: Number(
                          (prev.totalWeightKg + 0.3).toFixed(1)
                        ),
                      }));
                    }}
                  >
                    + Simulate Item Pickup
                  </button>
                  <button
                    type="button"
                    className={`yolo-action-btn ${useWebcam ? "active" : ""}`}
                    onClick={() => setUseWebcam((v) => !v)}
                  >
                    {useWebcam ? "📷 Stop Webcam" : "📷 Use Live Webcam"}
                  </button>
                </div>
              </div>

              {/* YOLO Viewport */}
              <div className="yolo-viewport">
                {useWebcam ? (
                  <video
                    ref={videoRef}
                    autoPlay
                    playsInline
                    muted
                    className="yolo-webcam-video"
                  />
                ) : (
                  <div className="yolo-simulated-scene">
                    {/* Simulated forward-facing robot pathway perspective */}
                    <div className="scene-sky-grid" />
                    <div className="scene-horizon-line" />
                    <div className="scene-road-trapezoid" />
                    <div
                      className={`scene-center-lane ${
                        executionState === "EXECUTING" ? "moving" : ""
                      }`}
                    />
                    <div className="yolo-watermark-label">YOLO</div>
                  </div>
                )}

                {/* Real-time YOLO Bounding Boxes */}
                {yoloBoxes.map((box) => (
                  <div
                    key={box.id}
                    className="yolo-bbox"
                    style={{
                      left: `${box.x}%`,
                      top: `${box.y}%`,
                      width: `${box.w}%`,
                      height: `${box.h}%`,
                      borderColor: box.color,
                    }}
                  >
                    <span
                      className="yolo-bbox-tag"
                      style={{ backgroundColor: box.color }}
                    >
                      {box.label} {(box.confidence * 100).toFixed(0)}%
                    </span>
                  </div>
                ))}

                <div className="yolo-hud-footer">
                  <span>
                    📍 GPS: {livePosition.lat.toFixed(5)},{" "}
                    {livePosition.lon.toFixed(5)}
                  </span>
                  <span>
                    🤖 Mode:{" "}
                    {activeRoute ? activeRoute.task_mode : "STANDBY_VISION"}
                  </span>
                  <span>
                    🗑️ Hopper Load: {wasteStats.totalWeightKg} kg
                  </span>
                </div>
              </div>
            </section>

            {/* BOTTOM ROW: Left = "Waste Collected" (2x2 Grid), Right = "Machine condition / Battery / Route : xx km" */}
            <div className="realtime-bottom-row">
              {/* Bottom-Left Box: Waste Collected */}
              <section className="waste-collected-card">
                <div className="section-box-title">
                  <span>Waste Collected</span>
                  <span className="weight-pill">
                    Total: {wasteStats.totalWeightKg} kg
                  </span>
                </div>
                <div className="waste-2x2-grid">
                  <div className="waste-cell">
                    <span className="waste-cell-label">
                      🥤 Plastic &amp; Cans
                    </span>
                    <strong className="waste-cell-val">
                      {wasteStats.plasticAndCans} items
                    </strong>
                  </div>
                  <div className="waste-cell">
                    <span className="waste-cell-label">
                      📦 Paper &amp; Packaging
                    </span>
                    <strong className="waste-cell-val">
                      {wasteStats.paperAndPackaging} items
                    </strong>
                  </div>
                  <div className="waste-cell">
                    <span className="waste-cell-label">
                      🗑️ Standard Bins Emptied
                    </span>
                    <strong className="waste-cell-val">
                      {wasteStats.binsEmptied} bins
                    </strong>
                  </div>
                  <div className="waste-cell">
                    <span className="waste-cell-label">
                      🛋️ Bulky / Heavy Waste
                    </span>
                    <strong
                      className="waste-cell-val"
                      style={{
                        color:
                          wasteStats.bulkyItems > 0 ? "#fbbf24" : "#f8fafc",
                      }}
                    >
                      {wasteStats.bulkyItems} items
                    </strong>
                  </div>
                </div>
              </section>

              {/* Bottom-Right Area: Machine condition, Battery, Route : xx km */}
              <section className="machine-condition-card">
                <div className="condition-row">
                  <span className="condition-key">Machine condition</span>
                  <strong className="condition-val">
                    {machineConditionText}
                  </strong>
                </div>

                <div className="condition-row">
                  <span className="condition-key">Battery</span>
                  <div className="condition-bar-wrap">
                    <div className="condition-bar-track">
                      <div
                        className="condition-bar-fill"
                        style={{
                          width: `${batteryPercent}%`,
                          background:
                            batteryPercent > 30 ? "#10b981" : "#ef4444",
                        }}
                      />
                    </div>
                    <strong className="condition-val">{batteryPercent}%</strong>
                  </div>
                </div>

                <div className="condition-row">
                  <span className="condition-key">Route : {totalRouteKm} km</span>
                  <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                    <span style={{ fontSize: 12, color: "#94a3b8" }}>
                      {activeRoute
                        ? `${routeProgressPct}% completed (${completedSegCount}/${totalSegCount} segs)`
                        : "No route active yet"}
                    </span>
                    <button
                      type="button"
                      className="btn-jump-route"
                      onClick={() => setActiveNav("ROUTE")}
                    >
                      Open Route Map →
                    </button>
                  </div>
                </div>
              </section>
            </div>
          </div>
        ) : (
          /* VIEW 2: ROUTE AUTOMATION VIEW */
          <div className="route-view-container">
            {/* Simple Guided Toolbar Above the Map */}
            <div className="route-automation-toolbar">
              <div className="toolbar-step">
                <span className="step-num">1. Select Area:</span>
                <button
                  type="button"
                  className={`tool-pill-btn ${
                    drawMode === "BOX_AREA" ? "active" : ""
                  }`}
                  onClick={() => setDrawMode("BOX_AREA")}
                >
                  📦 Draw Box (2 Clicks)
                </button>
                <button
                  type="button"
                  className={`tool-pill-btn ${
                    drawMode === "BOUNDARY" ? "active" : ""
                  }`}
                  onClick={() => {
                    setBoundary([]);
                    setDrawMode("BOUNDARY");
                  }}
                >
                  📐 Custom Shape
                </button>
                <select
                  className="preset-select"
                  value=""
                  onChange={(e) => {
                    const found = CAMPUS_PRESETS.find(
                      (p) => p.id === e.target.value
                    );
                    if (found) {
                      setBoundary(found.boundary);
                      setStartLocation(found.startLocation);
                      setDisposalLocation(found.disposalLocation);
                      setLivePosition(found.startLocation);
                      setMapCenter(found.center);
                      setStatusBanner(
                        `Selected ${found.name}. Now click a Zone Classification in Step 2 to start the route!`
                      );
                    }
                  }}
                >
                  <option value="" disabled>
                    📍 Or Pick Landmark...
                  </option>
                  {CAMPUS_PRESETS.map((p) => (
                    <option key={p.id} value={p.id}>
                      {p.name}
                    </option>
                  ))}
                </select>
              </div>

              <div className="toolbar-step">
                <span className="step-num">2. Classify &amp; Auto-Start:</span>
                <button
                  type="button"
                  className={`classify-pill-btn ${
                    selectedClassification === "STANDARD_SWEEP" ? "active" : ""
                  }`}
                  onClick={() => handleClassifyZone("STANDARD_SWEEP")}
                >
                  🧹 Standard Sweep
                </button>
                <button
                  type="button"
                  className={`classify-pill-btn ${
                    selectedClassification === "SWEEP_AND_BINS" ? "active" : ""
                  }`}
                  onClick={() => handleClassifyZone("SWEEP_AND_BINS")}
                >
                  ✨ Sweep + Bins
                </button>
                <button
                  type="button"
                  className={`classify-pill-btn ${
                    selectedClassification === "BIN_PICKUP_ONLY" ? "active" : ""
                  }`}
                  onClick={() => handleClassifyZone("BIN_PICKUP_ONLY")}
                >
                  🗑️ Bin Pickup
                </button>
                <button
                  type="button"
                  className={`classify-pill-btn ${
                    selectedClassification === "BULKY_WASTE" ? "active" : ""
                  }`}
                  onClick={() => handleClassifyZone("BULKY_WASTE")}
                >
                  🛋️ Bulky Waste
                </button>
              </div>

              <div className="toolbar-step">
                <span className="step-num">3. Live Auto-Replan:</span>
                <button
                  type="button"
                  className={`tool-pill-btn ${
                    drawMode === "INSTANT_OBSTACLE" ? "active" : ""
                  }`}
                  onClick={() => setDrawMode("INSTANT_OBSTACLE")}
                >
                  🚧 Mark Obstacle ({dynamicObstacles.length})
                </button>
                <button
                  type="button"
                  className={`tool-pill-btn ${
                    drawMode === "TASK" ? "active" : ""
                  }`}
                  onClick={() => setDrawMode("TASK")}
                >
                  🗑️ + Bin Pin ({tasks.length})
                </button>
                <button
                  type="button"
                  className={`tool-pill-btn ${
                    drawMode === "OVERSIZED" ? "active" : ""
                  }`}
                  onClick={() => setDrawMode("OVERSIZED")}
                >
                  🛋️ + Bulky Pin
                </button>
                <button
                  type="button"
                  className="tool-pill-btn clear"
                  onClick={handleClearMap}
                >
                  🔄 Clear Map
                </button>
              </div>
            </div>

            {/* Interactive Leaflet Map */}
            <div className="route-map-holder">
              <MapWorkspace
                center={mapCenter}
                drawMode={drawMode}
                drawnBoundary={boundary}
                exclusionVertices={[]}
                obstacleVertices={[]}
                eventReportLocation={null}
                livePosition={latestTelemetryFrame?.position ?? livePosition}
                boxCornerStart={
                  drawMode === "BOX_AREA" ? boxCornerStart : obstacleCornerStart
                }
                zoneLabel={selectedClassification?.replace(/_/g, " ") ?? null}
                dynamicObstacles={dynamicObstacles}
                tasks={tasks}
                startLocation={startLocation}
                disposalLocation={disposalLocation}
                activeRoute={activeRoute}
                onMapClick={handleMapClick}
              />
            </div>
          </div>
        )}
      </main>
    </div>
  );
};

export default App;
