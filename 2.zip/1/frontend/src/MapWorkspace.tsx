import React, { useEffect, useState } from "react";
import L from "leaflet";
import {
  MapContainer,
  TileLayer,
  Polygon,
  Polyline,
  Marker,
  Popup,
  CircleMarker,
  useMap,
  useMapEvents,
} from "react-leaflet";
import { Coordinate, DrawMode, RouteCandidate, TaskItem } from "./types/api";

export type ExtendedDrawMode =
  | DrawMode
  | "SELECT_ZONE"
  | "BOX_AREA"
  | "INSTANT_OBSTACLE";

export interface CampusZonePreset {
  id: string;
  shortLabel: string;
  name: string;
  subtitle: string;
  center: Coordinate;
  boundary: Coordinate[];
  exclusion: Coordinate[];
  exclusionName: string;
  startLocation: Coordinate;
  disposalLocation: Coordinate;
  defaultTasks: TaskItem[];
  recommendedMachineId: string;
  nlCommand: string;
}

interface MapWorkspaceProps {
  center: Coordinate;
  drawMode: ExtendedDrawMode;
  drawnBoundary: Coordinate[];
  exclusionVertices: Coordinate[];
  obstacleVertices: Coordinate[];
  dynamicObstacles: Array<{ id: string; name: string; vertices: Coordinate[] }>;
  eventReportLocation: Coordinate | null;
  tasks: TaskItem[];
  startLocation: Coordinate | null;
  disposalLocation: Coordinate | null;
  activeRoute: RouteCandidate | null;
  livePosition: Coordinate | null;
  onMapClick: (coord: Coordinate) => void;
  boxCornerStart?: Coordinate | null;
  zoneLabel?: string | null;
}

const ROUTE_STATUS_STYLES: Record<
  string,
  { color: string; dashArray?: string; weight: number }
> = {
  PROPOSED: { color: "#0284c7", weight: 4 },
  DRAFT_FAILED_KPI: { color: "#ef4444", dashArray: "5, 7", weight: 3 },
  APPROVED: { color: "#0284c7", weight: 4 },
  EXECUTING: { color: "#0284c7", weight: 4 },
  COMPLETED: { color: "#10b981", weight: 4 },
  SUPERSEDED: { color: "#94a3b8", dashArray: "3, 6", weight: 2 },
};

function makePillIcon(
  label: string,
  bg: string,
  border = "#ffffff",
  pulse = false
): L.DivIcon {
  return L.divIcon({
    className: "custom-div-icon",
    html: `<div style="
      background:${bg};
      color:#ffffff;
      border:2px solid ${border};
      border-radius:999px;
      min-width:30px;
      height:28px;
      padding:0 10px;
      display:inline-flex;
      align-items:center;
      justify-content:center;
      font-size:11.5px;
      font-weight:700;
      letter-spacing:0.2px;
      box-shadow:${
        pulse
          ? "0 0 0 5px rgba(16, 185, 129, 0.32), 0 4px 12px rgba(0,0,0,0.45)"
          : "0 3px 8px rgba(0,0,0,0.35)"
      };
      white-space:nowrap;
    ">${label}</div>`,
    iconSize: [30, 28],
    iconAnchor: [15, 14],
  });
}

function ClickAndHoverHandler({
  onClick,
  onHover,
}: {
  onClick: (c: Coordinate) => void;
  onHover: (c: Coordinate | null) => void;
}) {
  useMapEvents({
    click(e) {
      onClick({
        lat: Number(e.latlng.lat.toFixed(6)),
        lon: Number(e.latlng.lng.toFixed(6)),
      });
    },
    mousemove(e) {
      onHover({
        lat: Number(e.latlng.lat.toFixed(6)),
        lon: Number(e.latlng.lng.toFixed(6)),
      });
    },
    mouseout() {
      onHover(null);
    },
  });
  return null;
}

function MapCenterUpdater({ center }: { center: Coordinate }) {
  const map = useMap();
  useEffect(() => {
    map.setView([center.lat, center.lon], map.getZoom(), { animate: true });
  }, [center.lat, center.lon, map]);
  return null;
}

export const MapWorkspace: React.FC<MapWorkspaceProps> = ({
  center,
  drawMode,
  drawnBoundary,
  exclusionVertices,
  obstacleVertices,
  dynamicObstacles,
  eventReportLocation,
  tasks,
  startLocation,
  disposalLocation,
  activeRoute,
  livePosition,
  onMapClick,
  boxCornerStart = null,
  zoneLabel = null,
}) => {
  const [hoverCoord, setHoverCoord] = useState<Coordinate | null>(null);

  const routeStyle = activeRoute
    ? ROUTE_STATUS_STYLES[activeRoute.status] || ROUTE_STATUS_STYLES.PROPOSED
    : ROUTE_STATUS_STYLES.PROPOSED;

  const displayBoundary =
    drawnBoundary.length >= 3
      ? drawnBoundary
      : activeRoute?.operating_boundary?.vertices || [];

  const displayTasks =
    activeRoute && activeRoute.tasks.length > 0 ? activeRoute.tasks : tasks;
  const effectiveStart = startLocation || activeRoute?.origin || null;
  const effectiveDepot = disposalLocation || activeRoute?.disposal_depot || null;
  const robotPosition = livePosition || effectiveStart || center;

  // Live 2-Click Box Preview while user moves mouse after first click
  const previewBoxVertices: Coordinate[] =
    (drawMode === "BOX_AREA" || drawMode === "INSTANT_OBSTACLE" || drawMode === "OBSTACLE") && boxCornerStart && hoverCoord
      ? [
          { lat: boxCornerStart.lat, lon: boxCornerStart.lon },
          { lat: boxCornerStart.lat, lon: hoverCoord.lon },
          { lat: hoverCoord.lat, lon: hoverCoord.lon },
          { lat: hoverCoord.lat, lon: boxCornerStart.lon },
        ]
      : [];

  // Calculate center of selected boundary for a clean zone badge
  const boundaryCenter: Coordinate | null =
    displayBoundary.length >= 3
      ? {
          lat:
            displayBoundary.reduce((acc, c) => acc + c.lat, 0) /
            displayBoundary.length,
          lon:
            displayBoundary.reduce((acc, c) => acc + c.lon, 0) /
            displayBoundary.length,
        }
      : null;

  return (
    <MapContainer
      center={[center.lat, center.lon]}
      zoom={18}
      style={{ height: "100%", width: "100%" }}
    >
      <TileLayer
        attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
        url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
        maxZoom={21}
      />
      <MapCenterUpdater center={center} />
      <ClickAndHoverHandler onClick={onMapClick} onHover={setHoverCoord} />

      {/* 2-Click Rectangular Box Live Preview */}
      {previewBoxVertices.length === 4 && (
        <Polygon
          positions={previewBoxVertices.map((c) => [c.lat, c.lon])}
          pathOptions={{
            color: drawMode === "BOX_AREA" ? "#0284c7" : "#e11d48",
            weight: 2.5,
            dashArray: "6, 6",
            fillColor: drawMode === "BOX_AREA" ? "#38bdf8" : "#f43f5e",
            fillOpacity: 0.22,
          }}
        />
      )}

      {boxCornerStart && (
        <CircleMarker
          center={[boxCornerStart.lat, boxCornerStart.lon]}
          radius={7}
          pathOptions={{ color: "#0284c7", fillColor: "#ffffff", fillOpacity: 1 }}
        />
      )}

      {/* Selected Cleaning Zone Polygon */}
      {displayBoundary.length >= 3 && (
        <Polygon
          positions={displayBoundary.map((c) => [c.lat, c.lon])}
          pathOptions={{
            color: "#0284c7",
            weight: 3,
            fillColor: "#38bdf8",
            fillOpacity: 0.15,
          }}
        />
      )}

      {/* Zone Classification Label in Center of Selected Area */}
      {boundaryCenter && zoneLabel && (
        <Marker
          position={[boundaryCenter.lat, boundaryCenter.lon]}
          icon={makePillIcon(zoneLabel, "rgba(15, 23, 42, 0.85)", "#38bdf8")}
        />
      )}

      {/* Vertex handles while drawing custom polygon */}
      {drawMode === "BOUNDARY" &&
        drawnBoundary.map((v, i) => (
          <CircleMarker
            key={`bv-${i}`}
            center={[v.lat, v.lon]}
            radius={5}
            pathOptions={{ color: "#0284c7", fillColor: "#fff", fillOpacity: 1 }}
          />
        ))}

      {/* Restricted / Exclusion Zones */}
      {exclusionVertices.length >= 3 && (
        <Polygon
          positions={exclusionVertices.map((c) => [c.lat, c.lon])}
          pathOptions={{
            color: "#dc2626",
            weight: 2,
            fillColor: "#ef4444",
            fillOpacity: 0.35,
          }}
        />
      )}

      {obstacleVertices.length >= 3 && (
        <Polygon
          positions={obstacleVertices.map((c) => [c.lat, c.lon])}
          pathOptions={{
            color: "#e11d48",
            weight: 2.5,
            dashArray: "5, 5",
            fillColor: "#f43f5e",
            fillOpacity: 0.38,
          }}
        />
      )}

      {dynamicObstacles.map((obstacle) => (
        <Polygon
          key={obstacle.id}
          positions={obstacle.vertices.map((c) => [c.lat, c.lon])}
          pathOptions={{
            color: "#e11d48",
            weight: 2.5,
            dashArray: "5, 5",
            fillColor: "#f43f5e",
            fillOpacity: 0.38,
          }}
        >
          <Popup>{obstacle.name}</Popup>
        </Polygon>
      ))}

      {activeRoute?.exclusion_zones?.map((z) => (
        <Polygon
          key={z.zone_id}
          positions={z.polygon.vertices.map((c) => [c.lat, c.lon])}
          pathOptions={{
            color: "#dc2626",
            weight: 2,
            fillColor: "#ef4444",
            fillOpacity: 0.38,
          }}
        >
          <Popup>
            <strong>Blocked / Restricted Area</strong>
            <br />
            {z.name} ({z.reason})
          </Popup>
        </Polygon>
      ))}

      {/* Planned & Completed Cleaning Route Segments */}
      {activeRoute?.segments.map((seg, idx) => {
        if (!seg.waypoints || seg.waypoints.length < 2) return null;
        const positions = seg.waypoints.map(
          (w) => [w.lat, w.lon] as [number, number]
        );
        const isCompleted = seg.completed;
        const isSweep = seg.segment_type === "SWEEP_SWATH";
        const isTurn = seg.segment_type === "TURN_CONNECTOR";
        const isReturn = seg.segment_type === "RETURN_TO_BASE";

        const segColor = isCompleted
          ? "#10b981"
          : isReturn
          ? "#8b5cf6"
          : isTurn
          ? "#64748b"
          : routeStyle.color;

        return (
          <React.Fragment key={seg.segment_id}>
            {isSweep && (
              <Polyline
                positions={positions}
                pathOptions={{
                  color: isCompleted ? "#10b981" : "#38bdf8",
                  weight: 13,
                  opacity: 0.22,
                  lineCap: "round",
                }}
              />
            )}
            <Polyline
              positions={positions}
              pathOptions={{
                color: segColor,
                dashArray: isTurn
                  ? "4, 6"
                  : isReturn
                  ? "6, 6"
                  : routeStyle.dashArray,
                weight: isSweep ? 4 : 3,
                opacity: 0.95,
              }}
            >
              <Popup>
                <strong>
                  Step #{idx + 1}:{" "}
                  {isSweep
                    ? "Cleaning Pass"
                    : isTurn
                    ? "Turnaround"
                    : isReturn
                    ? "Return to Depot"
                    : "Travel Leg"}
                </strong>
                <br />
                Distance: {Math.round(seg.distance_m)}m · Est.{" "}
                {Math.round(seg.estimated_duration_sec)}s
                <br />
                Status:{" "}
                <strong>{seg.completed ? "✓ Cleaned" : "Scheduled"}</strong>
              </Popup>
            </Polyline>
          </React.Fragment>
        );
      })}

      {/* Start Point Marker (shown when route exists or custom start set) */}
      {effectiveStart && displayBoundary.length >= 3 && (
        <Marker
          position={[effectiveStart.lat, effectiveStart.lon]}
          icon={makePillIcon("🏁 Start", "#0284c7")}
        >
          <Popup>
            <strong>Cleaning Start Point</strong>
            <br />
            {effectiveStart.lat.toFixed(5)}, {effectiveStart.lon.toFixed(5)}
          </Popup>
        </Marker>
      )}

      {/* Disposal Depot Marker */}
      {effectiveDepot &&
        (displayBoundary.length >= 3 || displayTasks.length > 0) && (
          <Marker
            position={[effectiveDepot.lat, effectiveDepot.lon]}
            icon={makePillIcon("♻️ Depot", "#7c3aed")}
          >
            <Popup>
              <strong>Waste Disposal Depot</strong>
              <br />
              {effectiveDepot.lat.toFixed(5)}, {effectiveDepot.lon.toFixed(5)}
            </Popup>
          </Marker>
        )}

      {/* Bin & Bulky Waste Pins */}
      {displayTasks.map((t, idx) => {
        const isOversized =
          t.task_type === "OVERSIZED_RUBBISH" || t.rubbish_spec?.is_oversized;
        const bg = t.completed
          ? "#10b981"
          : isOversized
          ? "#e11d48"
          : "#2563eb";
        const label = t.completed
          ? `✓ Done #${idx + 1}`
          : isOversized
          ? `🛋️ Bulky #${idx + 1}`
          : `🗑️ Bin #${idx + 1}`;
        return (
          <Marker
            key={t.task_id}
            position={[t.location.lat, t.location.lon]}
            icon={makePillIcon(label, bg)}
          >
            <Popup>
              <strong>
                {isOversized ? "Bulky Waste Pickup" : "Bin Collection Stop"} #
                {idx + 1}
              </strong>
              <br />
              {t.rubbish_spec?.description || t.task_id}
              <br />
              Status:{" "}
              <strong>{t.completed ? "✓ Collected" : "Waiting"}</strong>
            </Popup>
          </Marker>
        );
      })}

      {eventReportLocation && (
        <Marker
          position={[eventReportLocation.lat, eventReportLocation.lon]}
          icon={makePillIcon("📍 Pin", "#f97316")}
        />
      )}

      {/* Always-Visible Live Robot Placement Marker */}
      <Marker
        position={[robotPosition.lat, robotPosition.lon]}
        icon={makePillIcon("🤖 Robot Live", "#059669", "#ffffff", true)}
      >
        <Popup>
          <strong>Active Cleaning Robot</strong>
          <br />
          Live GPS: {robotPosition.lat.toFixed(5)},{" "}
          {robotPosition.lon.toFixed(5)}
        </Popup>
      </Marker>
    </MapContainer>
  );
};
