import heapq
import math
from typing import Dict, List, Optional, Tuple
import httpx
from pydantic import BaseModel
from shapely import affinity
from shapely.geometry import LineString, MultiLineString, Point, Polygon
from shapely.ops import unary_union

try:
    import networkx as nx
    HAS_NETWORKX = True
except ImportError:
    nx = None  # type: ignore[assignment]
    HAS_NETWORKX = False

from .config import settings
from .models import (
    Coordinate,
    DataProvenance,
    ExclusionZone,
    GeoPolygon,
    MachineProfile,
    RouteSegment,
    TaskScheduleEntry,
    TaskItem,
    UnreachableSection,
)

try:
    from ortools.constraint_solver import pywrapcp, routing_enums_pb2
    HAS_ORTOOLS = True
except ImportError:
    HAS_ORTOOLS = False


def _shortest_path_fallback(
    nodes: List[Tuple[float, float]],
    edges: List[Tuple[Tuple[float, float], Tuple[float, float], float]],
    source: Tuple[float, float],
    target: Tuple[float, float],
) -> Tuple[Optional[List[Tuple[float, float]]], float]:
    adj: Dict[Tuple[float, float], List[Tuple[Tuple[float, float], float]]] = {n: [] for n in nodes}
    for u, v, w in edges:
        adj.setdefault(u, []).append((v, w))
        adj.setdefault(v, []).append((u, w))
    if source not in adj or target not in adj:
        return None, float("inf")
    dist: Dict[Tuple[float, float], float] = {source: 0.0}
    prev: Dict[Tuple[float, float], Tuple[float, float]] = {}
    pq: List[Tuple[float, Tuple[float, float]]] = [(0.0, source)]
    while pq:
        d, u = heapq.heappop(pq)
        if u == target:
            path = [target]
            curr = target
            while curr in prev:
                curr = prev[curr]
                path.append(curr)
            path.reverse()
            return path, d
        if d > dist.get(u, float("inf")):
            continue
        for nxt, w in adj.get(u, []):
            nd = d + w
            if nd < dist.get(nxt, float("inf")):
                dist[nxt] = nd
                prev[nxt] = u
                heapq.heappush(pq, (nd, nxt))
    return None, float("inf")


class CoveragePlanResult(BaseModel):
    segments: List[RouteSegment]
    target_area_m2: float
    covered_area_m2: float
    repeated_area_m2: float
    missed_area_m2: float
    coverage_percent: float
    repeated_coverage_percent: float
    sweep_distance_m: float
    turn_distance_m: float
    unreachable_sections: List[UnreachableSection]
    route_safety_issues: List[str] = []


class CoveragePlanner:
    """Mode A: Serpentine / Boustrophedon Area Coverage Planner."""

    @staticmethod
    def _safe_connector_path(
        start: Tuple[float, float], end: Tuple[float, float], safe_space,
    ) -> Optional[List[Tuple[float, float]]]:
        """Build a visibility-graph connector wholly inside eroded free space."""
        allowed = safe_space.buffer(0.02)
        direct = LineString([start, end])
        if allowed.covers(direct):
            return [start, end]
        if not allowed.covers(Point(start)) or not allowed.covers(Point(end)):
            return None

        nodes: List[Tuple[float, float]] = [start, end]

        def add_polygon_vertices(geometry) -> None:
            if isinstance(geometry, Polygon):
                nodes.extend((float(x), float(y)) for x, y in list(geometry.exterior.coords)[:-1])
                for ring in geometry.interiors:
                    nodes.extend((float(x), float(y)) for x, y in list(ring.coords)[:-1])
            elif hasattr(geometry, "geoms"):
                for child in geometry.geoms:
                    add_polygon_vertices(child)

        add_polygon_vertices(safe_space.simplify(0.05, preserve_topology=True))
        nodes = list(dict.fromkeys((round(x, 3), round(y, 3)) for x, y in nodes))
        if HAS_NETWORKX and nx is not None:
            graph = nx.Graph()
            graph.add_nodes_from(nodes)
            for i, a in enumerate(nodes):
                for b in nodes[i + 1:]:
                    line = LineString([a, b])
                    if allowed.covers(line):
                        graph.add_edge(a, b, weight=line.length)
            try:
                return nx.shortest_path(graph, nodes[0], nodes[1], weight="weight")
            except (nx.NetworkXNoPath, nx.NodeNotFound):
                return None
        else:
            edges: List[Tuple[Tuple[float, float], Tuple[float, float], float]] = []
            for i, a in enumerate(nodes):
                for b in nodes[i + 1:]:
                    line = LineString([a, b])
                    if allowed.covers(line):
                        edges.append((a, b, line.length))
            path, _ = _shortest_path_fallback(nodes, edges, nodes[0], nodes[1])
            return path

    def plan_coverage(
        self,
        boundary: GeoPolygon,
        exclusion_zones: List[ExclusionZone],
        machine: MachineProfile,
        sweep_angle_deg: float = 0.0,
        overlap_ratio: Optional[float] = None,
        completed_segments: Optional[List[RouteSegment]] = None,
    ) -> CoveragePlanResult:
        origin = boundary.vertices[0]
        outer_poly = boundary.to_shapely_local(origin)
        obs_polys = [z.polygon.to_shapely_local(origin) for z in exclusion_zones]
        obs_union = unary_union(obs_polys) if obs_polys else Polygon()
        free_space = outer_poly.difference(obs_union)
        safe_route_space = outer_poly.buffer(-machine.clearance_width_m / 2.0)
        if not obs_union.is_empty:
            safe_route_space = safe_route_space.difference(obs_union.buffer(machine.working_width_m / 2.0))
        target_area_m2 = max(free_space.area, 0.01)
        unreachable: List[UnreachableSection] = []

        already_swept = Polygon()
        retained: List[RouteSegment] = []
        if completed_segments:
            bufs = []
            for s in completed_segments:
                if s.completed and s.segment_type == "SWEEP_SWATH" and len(s.waypoints) >= 2:
                    pts = [w.to_local_meters(origin) for w in s.waypoints]
                    bufs.append(LineString(pts).buffer(machine.working_width_m / 2.0))
                    retained.append(s)
            if bufs:
                already_swept = unary_union(bufs).intersection(free_space)

        remaining = free_space.difference(already_swept)
        nav_core = safe_route_space.intersection(remaining)
        if nav_core.is_empty:
            return CoveragePlanResult(
                segments=retained,
                target_area_m2=round(target_area_m2, 2),
                covered_area_m2=round(already_swept.area, 2),
                repeated_area_m2=0.0,
                missed_area_m2=round(target_area_m2 - already_swept.area, 2),
                coverage_percent=round((already_swept.area / target_area_m2) * 100.0, 2),
                repeated_coverage_percent=0.0,
                sweep_distance_m=0.0,
                turn_distance_m=0.0,
                unreachable_sections=unreachable,
                route_safety_issues=[],
            )

        accessible = nav_core.intersection(remaining)
        eff_overlap = overlap_ratio if overlap_ratio is not None else machine.default_overlap_ratio
        eff_overlap = max(0.0, min(eff_overlap, 0.65))
        step = max(0.25, machine.working_width_m * (1.0 - eff_overlap))

        centroid = accessible.centroid
        rot_poly = affinity.rotate(accessible, -sweep_angle_deg, origin=centroid, use_radians=False)
        minx, miny, maxx, maxy = rot_poly.bounds
        inset = min(step * 0.02, machine.working_width_m * 0.02)
        y = miny + inset
        raw_swaths: List[LineString] = []
        ltr = True

        while y <= maxy - inset + 1e-6:
            scan = LineString([(minx - 10.0, y), (maxx + 10.0, y)]).intersection(rot_poly)
            lines = (
                [scan]
                if isinstance(scan, LineString)
                else (list(scan.geoms) if isinstance(scan, MultiLineString) else [])
            )
            lines.sort(key=lambda ln: ln.coords[0][0])
            if not ltr:
                lines.reverse()
                lines = [LineString(list(ln.coords)[::-1]) for ln in lines]
            for ln in lines:
                if ln.length >= 0.5:
                    raw_swaths.append(affinity.rotate(ln, sweep_angle_deg, origin=centroid, use_radians=False))
            ltr = not ltr
            y += step

        if eff_overlap >= 0.25 and isinstance(nav_core, Polygon) and nav_core.exterior.length > 2.0:
            raw_swaths.append(LineString(nav_core.exterior.coords))

        segments: List[RouteSegment] = list(retained)
        swath_polys: List[Polygon] = [already_swept] if not already_swept.is_empty else []
        tot_sweep = sum(s.distance_m for s in retained if s.segment_type == "SWEEP_SWATH")
        tot_turn = sum(s.distance_m for s in retained if s.segment_type == "TURN_CONNECTOR")
        raw_area = already_swept.area
        prev_end: Optional[Tuple[float, float]] = None
        safety_issues: List[str] = []

        for ln in raw_swaths:
            coords = list(ln.coords)
            if prev_end is not None:
                safe_connector_space = safe_route_space
                connector_points = (
                    self._safe_connector_path(prev_end, coords[0], safe_connector_space)
                    if not safe_connector_space.is_empty else None
                )
                if not connector_points:
                    connector = LineString([prev_end, coords[0]])
                    midpoint = connector.interpolate(0.5, normalized=True)
                    issue = "sweep_connector_unreachable: no validated path between adjacent swaths"
                    safety_issues.append(issue)
                    unreachable.append(
                        UnreachableSection(
                            section_id=f"connector-{len(safety_issues)}",
                            reason=issue,
                            area_m2=0.0,
                            centroid=Coordinate.from_local_meters(midpoint.x, midpoint.y, origin),
                        )
                    )
                else:
                    connector = LineString(connector_points)
                    arc = connector.length
                    segments.append(
                        RouteSegment(
                            segment_type="TURN_CONNECTOR",
                            waypoints=[Coordinate.from_local_meters(p[0], p[1], origin) for p in connector_points],
                            distance_m=round(arc, 2),
                            estimated_duration_sec=round(arc / max(machine.sweep_speed_mps * 0.75, 0.2), 2),
                        )
                    )
                    tot_turn += arc

            segments.append(
                RouteSegment(
                    segment_type="SWEEP_SWATH",
                    waypoints=[Coordinate.from_local_meters(p[0], p[1], origin) for p in coords],
                    distance_m=round(ln.length, 2),
                    estimated_duration_sec=round(ln.length / machine.sweep_speed_mps, 2),
                    swath_width_m=machine.working_width_m,
                )
            )
            tot_sweep += ln.length
            buf = ln.buffer(machine.working_width_m / 2.0).intersection(free_space)
            swath_polys.append(buf)
            raw_area += buf.area
            prev_end = coords[-1]

        cov_union = unary_union(swath_polys).intersection(free_space) if swath_polys else Polygon()
        cov_area = cov_union.area
        missed_area = max(0.0, target_area_m2 - cov_area)
        rep_area = max(0.0, raw_area - cov_area)
        cov_pct = min(100.0, (cov_area / target_area_m2) * 100.0)
        rep_pct = min(100.0, (rep_area / max(cov_area, 1.0)) * 100.0)

        return CoveragePlanResult(
            segments=segments,
            target_area_m2=round(target_area_m2, 2),
            covered_area_m2=round(cov_area, 2),
            repeated_area_m2=round(rep_area, 2),
            missed_area_m2=round(missed_area, 2),
            coverage_percent=round(cov_pct, 2),
            repeated_coverage_percent=round(rep_pct, 2),
            sweep_distance_m=round(tot_sweep, 2),
            turn_distance_m=round(tot_turn, 2),
            unreachable_sections=unreachable,
            route_safety_issues=safety_issues,
        )


class RoutingServiceUnavailableError(Exception):
    pass


class DistanceMatrixResult(BaseModel):
    distance_matrix_m: List[List[float]]
    duration_matrix_sec: List[List[float]]
    provenance: DataProvenance


class ValhallaRoutingService:
    """Mode B Geographic Route Planner via self-hosted Valhalla or labeled NetworkX grid."""

    def __init__(self, valhalla_url: str = settings.valhalla_url) -> None:
        self.valhalla_url = valhalla_url
        self._force_offline_for_test: bool = False
        self._valhalla_unavailable_for_session: bool = False

    def compute_matrix_and_paths(
        self, locations: List[Coordinate], cruise_speed_mps: float
    ) -> Tuple[DistanceMatrixResult, Dict[Tuple[int, int], List[Coordinate]]]:
        if not self._force_offline_for_test and not self._valhalla_unavailable_for_session:
            try:
                pts = [{"lat": c.lat, "lon": c.lon} for c in locations]
                with httpx.Client(timeout=1.5) as client:
                    r = client.post(
                        f"{self.valhalla_url}/sources_to_targets",
                        json={"sources": pts, "targets": pts, "costing": "auto", "units": "kilometers"},
                    )
                    r.raise_for_status()
                    data = r.json()
                    n = len(locations)
                    dm = [[0.0] * n for _ in range(n)]
                    tm = [[0.0] * n for _ in range(n)]
                    paths: Dict[Tuple[int, int], List[Coordinate]] = {}
                    for i, row in enumerate(data["sources_to_targets"]):
                        for j, cell in enumerate(row):
                            if cell.get("distance") is None or cell.get("time") is None:
                                raise RoutingServiceUnavailableError(f"No mapped route from point {i} to {j}.")
                            dm[i][j] = float(cell["distance"]) * 1000.0
                            tm[i][j] = float(cell["time"])
                            if i == j:
                                paths[(i, j)] = [locations[i]]
                                continue
                            route_response = client.post(
                                f"{self.valhalla_url}/route",
                                json={"locations": [pts[i], pts[j]], "costing": "auto", "units": "kilometers", "shape_format": "polyline6"},
                            )
                            route_response.raise_for_status()
                            trip = route_response.json().get("trip", {})
                            shape = trip.get("legs", [{}])[0].get("shape")
                            decoded = self._decode_polyline6(shape) if shape else []
                            if len(decoded) < 2:
                                raise RoutingServiceUnavailableError(f"Valhalla returned no route geometry from point {i} to {j}.")
                            paths[(i, j)] = decoded
                    return DistanceMatrixResult(distance_matrix_m=dm, duration_matrix_sec=tm, provenance=DataProvenance.PLANNED), paths
            except Exception as exc:
                if not settings.allow_labeled_demo_routing:
                    raise RoutingServiceUnavailableError(str(exc)) from exc
                self._valhalla_unavailable_for_session = True
        elif not settings.allow_labeled_demo_routing:
            raise RoutingServiceUnavailableError("Simulated Valhalla outage and fallback disabled.")

        origin = locations[0]
        local_pts = [c.to_local_meters(origin) for c in locations]
        xs = sorted(set(round(p[0], 2) for p in local_pts))
        ys = sorted(set(round(p[1], 2) for p in local_pts))
        grid_nodes = [(x, y) for x in xs for y in ys]
        grid_edges: List[Tuple[Tuple[float, float], Tuple[float, float], float]] = []
        for ix, x in enumerate(xs):
            for iy, y in enumerate(ys):
                if ix + 1 < len(xs):
                    grid_edges.append(((x, y), (xs[ix + 1], y), abs(xs[ix + 1] - x)))
                if iy + 1 < len(ys):
                    grid_edges.append(((x, y), (x, ys[iy + 1]), abs(ys[iy + 1] - y)))

        G = None
        if HAS_NETWORKX and nx is not None:
            G = nx.Graph()
            G.add_nodes_from(grid_nodes)
            for u_node, v_node, w_val in grid_edges:
                G.add_edge(u_node, v_node, weight=w_val)

        n = len(locations)
        dm = [[0.0] * n for _ in range(n)]
        tm = [[0.0] * n for _ in range(n)]
        paths: Dict[Tuple[int, int], List[Coordinate]] = {}
        for i in range(n):
            u = (round(local_pts[i][0], 2), round(local_pts[i][1], 2))
            for j in range(n):
                if i == j:
                    paths[(i, j)] = [locations[i]]
                    continue
                v = (round(local_pts[j][0], 2), round(local_pts[j][1], 2))
                if G is not None:
                    p_nodes = nx.shortest_path(G, u, v, weight="weight")
                    raw_len = nx.shortest_path_length(G, u, v, weight="weight")
                else:
                    p_nodes_opt, raw_len = _shortest_path_fallback(grid_nodes, grid_edges, u, v)
                    p_nodes = p_nodes_opt or [u, v]
                dist = max(raw_len * 1.08, 1.0)
                dm[i][j] = round(dist, 2)
                tm[i][j] = round(dist / max(cruise_speed_mps, 0.2), 2)
                paths[(i, j)] = [Coordinate.from_local_meters(px, py, origin) for (px, py) in p_nodes]

        return (
            DistanceMatrixResult(
                distance_matrix_m=dm,
                duration_matrix_sec=tm,
                provenance=DataProvenance.SYNTHETIC_FALLBACK_GRAPH,
            ),
            paths,
        )

    @staticmethod
    def _decode_polyline6(encoded: str) -> List[Coordinate]:
        coords: List[Coordinate] = []
        index = lat = lon = 0
        while index < len(encoded):
            values = []
            for _ in range(2):
                result = shift = 0
                while True:
                    b = ord(encoded[index]) - 63
                    index += 1
                    result |= (b & 0x1f) << shift
                    shift += 5
                    if b < 0x20:
                        break
                values.append(~(result >> 1) if result & 1 else result >> 1)
            lat += values[0]
            lon += values[1]
            coords.append(Coordinate(lat=lat / 1_000_000, lon=lon / 1_000_000))
        return coords


class OptimizedCollectionPlan(BaseModel):
    ordered_tasks: List[TaskItem]
    skipped_optional_tasks: List[TaskItem]
    task_schedule: List[TaskScheduleEntry] = []
    segments: List[RouteSegment]
    total_transit_distance_m: float
    disposal_trips: int
    peak_payload_kg: float = 0.0
    peak_payload_volume_m3: float = 0.0


class RouteOptimizationEngine:
    """Deterministic collection scheduler with windows, service time, and payload limits."""

    def optimize_collection_route(
        self,
        start_location: Coordinate,
        disposal_depot: Coordinate,
        tasks: List[TaskItem],
        machine: MachineProfile,
        dist_matrix_m: List[List[float]],
        time_matrix_sec: List[List[float]],
        paths: Dict[Tuple[int, int], List[Coordinate]],
        provenance: DataProvenance,
        prune_lowest_priority_if_over_budget: bool = False,
        start_elapsed_min: float = 0.0,
    ) -> OptimizedCollectionPlan:
        active = [t for t in tasks if not t.completed]
        if not active:
            return OptimizedCollectionPlan(
                ordered_tasks=[], skipped_optional_tasks=[], task_schedule=[], segments=[],
                total_transit_distance_m=0.0, disposal_trips=0,
                peak_payload_kg=machine.current_payload_kg,
                peak_payload_volume_m3=machine.current_payload_volume_m3,
            )

        ordered_idx, schedule, disposal_flags = self._schedule_indices(
            active, dist_matrix_m, time_matrix_sec, machine, start_elapsed_min
        )
        selected = set(ordered_idx)
        skipped = [task for i, task in enumerate(active) if i not in selected]
        segments: List[RouteSegment] = []
        ordered_tasks: List[TaskItem] = []
        curr_idx = 0
        depot_idx = len(active) + 1
        tot_dist = 0.0
        trips = 0

        for position, idx in enumerate(ordered_idx):
            t = active[idx]
            node = idx + 1
            if disposal_flags[position]:
                depot_d = dist_matrix_m[curr_idx][depot_idx]
                depot_t = time_matrix_sec[curr_idx][depot_idx]
                segments.append(RouteSegment(
                    segment_type="RETURN_TO_BASE",
                    waypoints=paths.get((curr_idx, depot_idx), [disposal_depot]),
                    distance_m=round(depot_d, 2), estimated_duration_sec=round(depot_t, 2),
                    target_task_id=t.task_id,
                    provenance=provenance,
                ))
                tot_dist += depot_d
                trips += 1
                curr_idx = depot_idx
            leg_d = dist_matrix_m[curr_idx][node]
            leg_t = time_matrix_sec[curr_idx][node]
            segments.append(
                RouteSegment(
                    segment_type="TRANSIT",
                    waypoints=paths.get((curr_idx, node), [t.location]),
                    distance_m=round(leg_d, 2),
                    estimated_duration_sec=round(leg_t, 2),
                    target_task_id=t.task_id,
                    provenance=provenance,
                )
            )
            if schedule[position].waiting_min > 0.001:
                segments.append(RouteSegment(
                    segment_type="WAIT_FOR_WINDOW",
                    waypoints=[t.location],
                    distance_m=0.0,
                    estimated_duration_sec=round(schedule[position].waiting_min * 60.0, 2),
                    target_task_id=t.task_id,
                ))
            segments.append(
                RouteSegment(
                    segment_type="COLLECTION_STOP",
                    waypoints=[t.location],
                    distance_m=0.0,
                    estimated_duration_sec=round(t.service_duration_sec, 2),
                    target_task_id=t.task_id,
                )
            )
            tot_dist += leg_d
            curr_idx = node
            ordered_tasks.append(t)

        ret_d = dist_matrix_m[curr_idx][depot_idx]
        ret_t = time_matrix_sec[curr_idx][depot_idx]
        segments.append(
            RouteSegment(
                segment_type="RETURN_TO_BASE",
                waypoints=paths.get((curr_idx, depot_idx), [disposal_depot]),
                distance_m=round(ret_d, 2),
                estimated_duration_sec=round(ret_t, 2),
                provenance=provenance,
            )
        )
        tot_dist += ret_d
        trips += 1
        peak_payload_kg = machine.current_payload_kg
        peak_payload_volume = machine.current_payload_volume_m3
        payload_kg = machine.current_payload_kg
        payload_volume = machine.current_payload_volume_m3
        for idx, dump in zip(ordered_idx, disposal_flags):
            if dump:
                payload_kg = 0.0
                payload_volume = 0.0
            spec = active[idx].rubbish_spec
            if spec:
                payload_kg += spec.estimated_weight_kg or 0.0
                payload_volume += spec.estimated_volume_m3 or 0.0
            peak_payload_kg = max(peak_payload_kg, payload_kg)
            peak_payload_volume = max(peak_payload_volume, payload_volume)

        return OptimizedCollectionPlan(
            ordered_tasks=ordered_tasks,
            skipped_optional_tasks=skipped,
            task_schedule=schedule,
            segments=segments,
            total_transit_distance_m=round(tot_dist, 2),
            disposal_trips=trips,
            peak_payload_kg=peak_payload_kg,
            peak_payload_volume_m3=peak_payload_volume,
        )

    def _schedule_indices(
        self,
        tasks: List[TaskItem],
        dm: List[List[float]],
        tm: List[List[float]],
        machine: MachineProfile,
        start_elapsed_min: float = 0.0,
    ) -> Tuple[List[int], List[TaskScheduleEntry], List[bool]]:
        depot = len(tasks) + 1
        budget = 16000
        visited = 0
        best_order: List[int] = []
        best_records: List[Tuple[int, float, float, float, float, bool, float, float]] = []
        best_rank: Tuple[object, ...] = (-1, -1, -1, float("-inf"), ())

        def task_load(index: int) -> Tuple[float, float]:
            spec = tasks[index].rubbish_spec
            return (
                (spec.estimated_weight_kg or 0.0) if spec else 0.0,
                (spec.estimated_volume_m3 or 0.0) if spec else 0.0,
            )

        def rank_for(
            order: List[int], records: List[Tuple[int, float, float, float, float, bool, float, float]],
            elapsed: float, current_node: int,
        ) -> Tuple[object, ...]:
            finish = elapsed + tm[current_node][depot] / 60.0
            priority_position_score = sum(
                tasks[index].priority * (len(order) - position)
                for position, index in enumerate(order)
            )
            return (
                len(order), sum(tasks[i].priority for i in order),
                priority_position_score, -finish, tuple(-i for i in order),
            )

        if len(tasks) > 9:
            order: List[int] = []
            records: List[Tuple[int, float, float, float, float, bool, float, float]] = []
            remaining = set(range(len(tasks)))
            elapsed = start_elapsed_min
            current_node = 0
            load_kg = machine.current_payload_kg
            load_vol = machine.current_payload_volume_m3
            while remaining:
                choices = []
                for i in remaining:
                    task = tasks[i]
                    weight, volume = task_load(i)
                    dump = (
                        load_kg + weight > machine.max_payload_kg
                        or load_vol + volume > machine.max_payload_volume_m3
                    )
                    travel = (tm[current_node][depot] + tm[depot][i + 1]) if dump else tm[current_node][i + 1]
                    arrival = elapsed + travel / 60.0
                    start = max(arrival, task.time_window_start_min)
                    end = start + task.service_duration_sec / 60.0
                    if end <= task.time_window_end_min + 1e-9:
                        slack = task.time_window_end_min - end
                        choices.append(((-task.priority, slack, travel, i), i, arrival, start, end, dump, weight, volume))
                if not choices:
                    break
                _, i, arrival, start, end, dump, weight, volume = min(choices, key=lambda c: c[0])
                if dump:
                    load_kg = 0.0
                    load_vol = 0.0
                    current_node = depot
                load_kg += weight
                load_vol += volume
                records.append((i, arrival, start, end, max(0.0, start - arrival), dump, load_kg, load_vol))
                order.append(i)
                remaining.remove(i)
                elapsed = end
                current_node = i + 1
            best_order, best_records = order, records
        else:
            def visit(
                remaining: Tuple[int, ...], order: List[int],
                records: List[Tuple[int, float, float, float, float, bool, float, float]],
                elapsed: float, current_node: int, load_kg: float, load_vol: float,
            ) -> None:
                nonlocal visited, best_order, best_records, best_rank
                if visited >= budget:
                    return
                visited += 1
                rank = rank_for(order, records, elapsed, current_node)
                if rank > best_rank:
                    best_rank = rank
                    best_order = list(order)
                    best_records = list(records)
                possible = []
                for i in remaining:
                    task = tasks[i]
                    weight, volume = task_load(i)
                    dump = load_kg + weight > machine.max_payload_kg or load_vol + volume > machine.max_payload_volume_m3
                    travel = (tm[current_node][depot] + tm[depot][i + 1]) if dump else tm[current_node][i + 1]
                    arrival = elapsed + travel / 60.0
                    start = max(arrival, task.time_window_start_min)
                    end = start + task.service_duration_sec / 60.0
                    if end <= task.time_window_end_min + 1e-9:
                        possible.append((tasks[i].time_window_end_min, -task.priority, travel, i, arrival, start, end, dump, weight, volume))
                for _, _, _, i, arrival, start, end, dump, weight, volume in sorted(possible):
                    next_kg = 0.0 if dump else load_kg
                    next_vol = 0.0 if dump else load_vol
                    next_kg += weight
                    next_vol += volume
                    visit(
                        tuple(j for j in remaining if j != i), order + [i],
                        records + [(i, arrival, start, end, max(0.0, start - arrival), dump, next_kg, next_vol)],
                        end, i + 1, next_kg, next_vol,
                    )

            visit(
                tuple(range(len(tasks))), [], [], start_elapsed_min, 0,
                machine.current_payload_kg, machine.current_payload_volume_m3,
            )

        schedule = [
            TaskScheduleEntry(
                task_id=tasks[i].task_id,
                arrival_min=round(arrival, 3),
                service_start_min=round(start, 3),
                service_end_min=round(end, 3),
                waiting_min=round(waiting, 3),
                window_start_min=tasks[i].time_window_start_min,
                window_end_min=tasks[i].time_window_end_min,
                priority=tasks[i].priority,
                disposal_before=dump,
            )
            for i, arrival, start, end, waiting, dump, _, _ in best_records
        ]
        disposal_flags = [record[5] for record in best_records]
        return best_order, schedule, disposal_flags

    def _solve_indices(self, tasks: List[TaskItem], dm: List[List[float]]) -> List[int]:
        if HAS_ORTOOLS:
            n = len(tasks) + 2
            mgr = pywrapcp.RoutingIndexManager(n, 1, [0], [n - 1])
            rt = pywrapcp.RoutingModel(mgr)
            cb = rt.RegisterTransitCallback(
                lambda i, j: int(dm[mgr.IndexToNode(i)][mgr.IndexToNode(j)])
            )
            rt.SetArcCostEvaluatorOfAllVehicles(cb)
            params = pywrapcp.DefaultRoutingSearchParameters()
            params.first_solution_strategy = routing_enums_pb2.FirstSolutionStrategy.PATH_CHEAPEST_ARC
            sol = rt.SolveWithParameters(params)
            if sol:
                out = []
                idx = rt.Start(0)
                while not rt.IsEnd(idx):
                    node = mgr.IndexToNode(idx)
                    if 1 <= node <= len(tasks):
                        out.append(node - 1)
                    idx = sol.Value(rt.NextVar(idx))
                return out
        return sorted(range(len(tasks)), key=lambda i: (-tasks[i].priority, dm[0][i + 1]))