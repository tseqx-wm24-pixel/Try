from __future__ import annotations

import secrets
from typing import Any, Dict, Optional

from fastapi import Depends, FastAPI, HTTPException, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from pydantic import BaseModel, Field

from .config import settings
from .execution import InvalidStateTransitionError, SafetyInterlockError
from .models import ExecutionState, OperationalEventRequest, OperatorRole, PlanRequest, RouteCandidate, TaskItem, TelemetryFrame
from .orchestrator import AgenticWorkflowOrchestrator, StaleRouteVersionError
from .planners import RoutingServiceUnavailableError
from .validators import LocationValidationError

app = FastAPI(
    title=settings.app_name,
    version="1.2.0",
    description="Local autonomous route planning API. Hardware control is disabled.",
)
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origins,
    allow_methods=["GET", "POST", "OPTIONS"],
    allow_headers=["Authorization", "Content-Type"],
)

orchestrator = AgenticWorkflowOrchestrator()
bearer_scheme = HTTPBearer(auto_error=False)


def get_operator_role(
    credentials: Optional[HTTPAuthorizationCredentials] = Depends(bearer_scheme),
) -> OperatorRole:
    if credentials is None or not credentials.credentials:
        raise HTTPException(status_code=401, detail="Bearer token required")
    tokens = {
        OperatorRole.OPERATOR: settings.operator_token,
        OperatorRole.SUPERVISOR: settings.supervisor_token,
        OperatorRole.ADMIN: settings.admin_token,
        OperatorRole.INTERNAL_SERVICE: settings.internal_service_token,
    }
    for role, token in tokens.items():
        if token and secrets.compare_digest(credentials.credentials, token):
            return role
    if not any(tokens.values()):
        raise HTTPException(status_code=503, detail="Configure AARPES_OPERATOR_TOKEN before using operational APIs")
    raise HTTPException(status_code=403, detail="Invalid bearer token")


def require_human_role(role: OperatorRole) -> None:
    if role not in (OperatorRole.OPERATOR, OperatorRole.SUPERVISOR, OperatorRole.ADMIN):
        raise HTTPException(status_code=403, detail="A human operator role is required")


class ExecuteRequest(BaseModel):
    stop_after_segments: Optional[int] = Field(default=None, ge=1)


@app.post("/api/tasks", response_model=TaskItem)
def create_task(task: TaskItem, role: OperatorRole = Depends(get_operator_role)) -> TaskItem:
    require_human_role(role)
    cached = orchestrator.audit.check_idempotency(task.idempotency_key)
    if cached:
        return cached
    orchestrator.audit.save_idempotency(task.idempotency_key, task)
    orchestrator.audit.record("global-tasks", role.value, "CREATE_TASK", f"Created task {task.task_id}")
    return task


@app.post("/api/routes/plan", response_model=RouteCandidate)
def plan_route(req: PlanRequest, role: OperatorRole = Depends(get_operator_role)) -> RouteCandidate:
    require_human_role(role)
    try:
        return orchestrator.plan_and_optimize(req, actor=role.value)
    except LocationValidationError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    except RoutingServiceUnavailableError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    except SafetyInterlockError as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc


def find_route(route_id: str) -> RouteCandidate:
    route = orchestrator.routes_by_id.get(route_id)
    if route is None:
        raise HTTPException(status_code=404, detail="Route not found")
    return route


@app.get("/api/routes/{route_id}", response_model=RouteCandidate)
def get_route(route_id: str, _role: OperatorRole = Depends(get_operator_role)) -> RouteCandidate:
    return orchestrator.refresh_route_evaluation(find_route(route_id))


@app.get("/api/routes/{route_id}/metrics")
def get_route_metrics(route_id: str, _role: OperatorRole = Depends(get_operator_role)) -> Dict[str, Any]:
    route = find_route(route_id)
    frames = orchestrator.simulator.telemetry_store.get(route_id, [])
    orchestrator.refresh_route_evaluation(route)
    return {
        "route_id": route.route_id,
        "job_id": route.job_id,
        "route_version": route.route_version,
        "status": route.status.value,
        "execution_state": orchestrator.state_machine.get_state(route.job_id).value,
        "kpi_evaluation": route.kpi_evaluation,
        "telemetry_count": len(frames),
        "telemetry_frames": frames[-20:],
        "audit_log": [
            entry for entry in orchestrator.audit._audit_log if entry.job_id == route.job_id
        ][-30:],
        "history_versions": [
            {
                "route_id": item.route_id,
                "version": item.route_version,
                "status": item.status.value,
                "passed": bool(item.kpi_evaluation and item.kpi_evaluation.passed),
                "score": item.kpi_evaluation.score if item.kpi_evaluation else 0.0,
                "coverage_percent": (
                    item.kpi_evaluation.metrics["coverage_percent"].actual
                    if item.kpi_evaluation and "coverage_percent" in item.kpi_evaluation.metrics
                    else None
                ),
                "total_distance_m": round(item.total_distance_m, 1),
                "estimated_duration_minutes": round(item.estimated_duration_minutes, 1),
                "sweep_angle_deg": item.sweep_angle_deg,
                "overlap_ratio": item.overlap_ratio,
                "failed_constraints": item.kpi_evaluation.failed_constraints if item.kpi_evaluation else [],
            }
            for item in orchestrator.job_route_history.get(route.job_id, [])
        ],
    }


@app.post("/api/routes/{route_id}/approve", response_model=RouteCandidate)
def approve_route(route_id: str, role: OperatorRole = Depends(get_operator_role)) -> RouteCandidate:
    require_human_role(role)
    try:
        return orchestrator.approve_route(route_id, actor=role.value, role=role)
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except PermissionError as exc:
        raise HTTPException(status_code=403, detail=str(exc)) from exc
    except (StaleRouteVersionError, SafetyInterlockError) as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc


@app.post("/api/routes/{route_id}/execute")
def execute_route(
    route_id: str, body: Optional[ExecuteRequest] = None,
    role: OperatorRole = Depends(get_operator_role),
) -> Dict[str, Any]:
    require_human_role(role)
    route = find_route(route_id)
    machine = orchestrator.machines[route.machine_id]
    try:
        frames = orchestrator.simulator.execute_simulation(
            route, machine, stop_after_segments=body.stop_after_segments if body else None,
        )
        orchestrator.refresh_route_evaluation(route)
        return {"route_id": route_id, "status": route.status.value,
                "execution_state": orchestrator.state_machine.get_state(route.job_id).value,
                "telemetry_frames_generated": len(frames),
                "remaining_battery_percent": machine.current_battery_percent,
                "provenance": "SIMULATED"}
    except SafetyInterlockError as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc


@app.post("/api/routes/{route_id}/pause")
def pause_route(route_id: str, role: OperatorRole = Depends(get_operator_role)) -> Dict[str, str]:
    require_human_role(role)
    route = find_route(route_id)
    if route.status.value != "EXECUTING":
        raise HTTPException(status_code=409, detail="Pause is only available for a route in execution")
    try:
        state = orchestrator.state_machine.transition(
            route.job_id, ExecutionState.PAUSED, role.value, "Operator requested safe pause", role=role,
        )
        return {"route_id": route_id, "state": state.value}
    except (InvalidStateTransitionError, SafetyInterlockError) as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc


@app.post("/api/routes/{route_id}/resume")
def resume_route(
    route_id: str, body: Optional[ExecuteRequest] = None,
    role: OperatorRole = Depends(get_operator_role),
) -> Dict[str, Any]:
    require_human_role(role)
    route = find_route(route_id)
    machine = orchestrator.machines[route.machine_id]
    try:
        orchestrator.state_machine.transition(
            route.job_id, ExecutionState.EXECUTING, role.value, "Operator resumed paused operation", role=role,
            mandatory_constraints_passed=bool(route.kpi_evaluation and route.kpi_evaluation.passed),
        )
        frames = orchestrator.simulator.execute_simulation(
            route, machine, stop_after_segments=body.stop_after_segments if body else None,
        )
        orchestrator.refresh_route_evaluation(route)
        return {"route_id": route_id, "state": orchestrator.state_machine.get_state(route.job_id).value,
                "total_telemetry_frames": len(frames), "provenance": "SIMULATED"}
    except (InvalidStateTransitionError, SafetyInterlockError) as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc


@app.post("/api/routes/{route_id}/replan")
def replan_route(
    route_id: str, event: OperationalEventRequest,
    role: OperatorRole = Depends(get_operator_role),
) -> Dict[str, Any]:
    require_human_role(role)
    event.route_id = route_id
    try:
        return orchestrator.handle_operational_event(event, actor=role.value, role=role)
    except RoutingServiceUnavailableError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    except (SafetyInterlockError, LocationValidationError, StaleRouteVersionError) as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc


@app.post("/api/events")
def submit_event(event: OperationalEventRequest, role: OperatorRole = Depends(get_operator_role)) -> Dict[str, Any]:
    require_human_role(role)
    try:
        return orchestrator.handle_operational_event(event, actor=role.value, role=role)
    except RoutingServiceUnavailableError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    except (SafetyInterlockError, LocationValidationError, StaleRouteVersionError) as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc


@app.post("/api/safety/reset-estop")
def reset_emergency_stop(_role: OperatorRole = Depends(get_operator_role)) -> None:
    raise HTTPException(status_code=501, detail="E-stop reset requires a configured trusted machine adapter")


@app.post("/api/telemetry")
def ingest_telemetry(
    frame: TelemetryFrame, role: OperatorRole = Depends(get_operator_role),
) -> Dict[str, Any]:
    if role != OperatorRole.INTERNAL_SERVICE:
        raise HTTPException(status_code=403, detail="Telemetry ingestion requires an internal service token")
    if frame.route_id not in orchestrator.routes_by_id:
        raise HTTPException(status_code=404, detail="Telemetry route not found")
    route = orchestrator.routes_by_id[frame.route_id]
    if orchestrator._latest_route_by_job.get(route.job_id) != frame.route_id:
        raise HTTPException(status_code=409, detail="Telemetry references a stale route version")
    if frame.machine_id != route.machine_id:
        raise HTTPException(status_code=409, detail="Telemetry machine does not match the route machine")
    frames = orchestrator.simulator.telemetry_store.setdefault(frame.route_id, [])
    if any(existing.telemetry_id == frame.telemetry_id for existing in frames):
        return {"ingested": frame.telemetry_id, "duplicate": True, "event_result": None}
    if frames and frame.mission_elapsed_min < frames[-1].mission_elapsed_min:
        if frame.mission_elapsed_min == 0.0:
            frame.mission_elapsed_min = frames[-1].mission_elapsed_min
        else:
            raise HTTPException(status_code=409, detail="Telemetry mission time moved backwards")
    frames.append(frame)
    machine = orchestrator.machines[route.machine_id]
    machine.current_battery_percent = frame.battery_percent
    machine.current_payload_kg = frame.payload_kg
    machine.current_payload_volume_m3 = frame.payload_volume_m3
    event_result = None
    state = orchestrator.state_machine.get_state(route.job_id)
    should_replan_deviation = (
        frame.route_deviation_m > settings.kpi_policy.max_route_deviation_m
        and state in (
            ExecutionState.AWAITING_APPROVAL, ExecutionState.EXECUTING,
            ExecutionState.PAUSED, ExecutionState.READY,
        )
    )
    should_replan_low_battery = (
        frame.battery_percent < settings.kpi_policy.min_energy_reserve_percent
        and state in (
            ExecutionState.AWAITING_APPROVAL, ExecutionState.EXECUTING,
            ExecutionState.PAUSED, ExecutionState.READY,
        )
    )
    if (
        frame.emergency_stop_engaged or frame.sensor_fault or frame.obstacle_blocked
        or should_replan_deviation or should_replan_low_battery
    ):
        kind = (
            "EMERGENCY_STOP" if frame.emergency_stop_engaged else
            "SENSOR_FAULT" if frame.sensor_fault else
            "OBSTACLE_DETECTED" if frame.obstacle_blocked else
            "HIGH_ROUTE_DEVIATION" if should_replan_deviation else "LOW_BATTERY"
        )
        event_result = orchestrator.handle_operational_event(
            OperationalEventRequest(
                job_id=route.job_id, route_id=route.route_id, event_type=kind,
                location=frame.position if should_replan_deviation else None,
                battery_percent=frame.battery_percent if should_replan_low_battery else None,
                idempotency_key=f"telemetry:{frame.telemetry_id}",
            ),
            actor=role.value, role=role,
        )
    else:
        orchestrator.refresh_route_evaluation(route)
    return {"ingested": frame.telemetry_id, "event_result": event_result}


@app.get("/api/health")
def health_check() -> Dict[str, Any]:
    return {"status": "healthy", "valhalla_configured_url": settings.valhalla_url,
            "labeled_demo_routing_enabled": settings.allow_labeled_demo_routing,
            "hardware_ros2_actuation_enabled": settings.enable_hardware_ros2_adapter,
            "simulation_only": True,
            "geocoding_configured": False,
            "kpi_policy_version": settings.kpi_policy.policy_version}


@app.websocket("/ws/telemetry/{route_id}")
async def telemetry_websocket(websocket: WebSocket, route_id: str) -> None:
    token = websocket.query_params.get("token", "")
    if not settings.operator_token or not secrets.compare_digest(token, settings.operator_token):
        await websocket.close(code=1008)
        return
    await websocket.accept()
    try:
        for frame in orchestrator.simulator.telemetry_store.get(route_id, []):
            await websocket.send_json(frame.model_dump(mode="json"))
    except WebSocketDisconnect:
        pass
    finally:
        await websocket.close()
