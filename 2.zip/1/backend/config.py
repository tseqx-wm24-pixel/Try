from typing import Optional
from pydantic import BaseModel, Field

try:
    from pydantic_settings import BaseSettings
except ImportError:
    BaseSettings = BaseModel  # type: ignore[misc,assignment]


class KPIPolicyConfig(BaseModel):
    """Operator-configurable, versioned KPI acceptance policy."""
    policy_version: str = Field(default="v1.2.0")
    min_coverage_percent: float = Field(default=92.0, ge=0.0, le=100.0)
    max_missed_coverage_percent: float = Field(default=8.0, ge=0.0, le=100.0)
    max_estimated_duration_minutes: float = Field(default=90.0, gt=0.0)
    max_travel_distance_m: float = Field(default=15000.0, gt=0.0)
    min_energy_reserve_percent: float = Field(default=20.0, ge=5.0, le=95.0)
    max_payload_utilization_percent: float = Field(default=95.0, ge=10.0, le=100.0)
    required_collection_completion_rate: float = Field(default=100.0, ge=0.0, le=100.0)
    max_route_deviation_m: float = Field(default=5.0, gt=0.0)
    max_repeated_coverage_percent: float = Field(default=18.0, ge=0.0, le=100.0)


class OptimizationLoopConfig(BaseModel):
    """Bounded feedback loop parameters."""
    max_iterations: int = Field(default=5, ge=1, le=20)
    timeout_seconds: float = Field(default=15.0, gt=0.5)
    min_improvement_epsilon: float = Field(default=0.25, ge=0.0)
    candidate_sweep_angles_deg: list[float] = Field(
        default_factory=lambda: [0.0, 90.0, 45.0, 135.0, 30.0]
    )
    overlap_step_increment: float = Field(default=0.03, ge=0.01, le=0.25)


class AppSettings(BaseSettings):
    app_name: str = "Agentic Autonomous Route Planning and Execution System"
    environment: str = "development"
    database_url: Optional[str] = None
    valhalla_url: str = "http://localhost:8002"
    nominatim_url: Optional[str] = None
    local_llm_url: Optional[str] = None  # Optional self-hosted Ollama endpoint
    allow_labeled_demo_routing: bool = True
    enable_hardware_ros2_adapter: bool = False  # Never enable real actuation by default
    telemetry_retention_days: int = 90
    operator_token: Optional[str] = "dev-operator-token"
    supervisor_token: Optional[str] = "dev-supervisor-token"
    admin_token: Optional[str] = "dev-admin-token"
    internal_service_token: Optional[str] = "dev-service-token"
    cors_origins: list[str] = Field(
        default_factory=lambda: [
            "http://localhost:5173",
            "http://127.0.0.1:5173",
            "http://localhost:4173",
            "http://127.0.0.1:4173",
            "http://localhost:3000",
            "http://localhost:8000",
        ]
    )
    kpi_policy: KPIPolicyConfig = Field(default_factory=KPIPolicyConfig)
    optimization: OptimizationLoopConfig = Field(default_factory=OptimizationLoopConfig)

    model_config = {"env_prefix": "AARPES_", "extra": "ignore"}


settings = AppSettings()
