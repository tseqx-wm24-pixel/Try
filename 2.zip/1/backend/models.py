from __future__ import annotations
import math
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Dict, List, Optional, Tuple
from uuid import uuid4
from pydantic import BaseModel, Field, model_validator
from shapely.geometry import Polygon

POSTGIS_INIT_SQL = """
CREATE EXTENSION IF NOT EXISTS postgis;
CREATE TABLE IF NOT EXISTS jobs (
    job_id VARCHAR(64) PRIMARY KEY,
    machine_id VARCHAR(64) NOT NULL,
    execution_state VARCHAR(32) NOT NULL DEFAULT 'IDLE',
    active_epoch INTEGER NOT NULL DEFAULT 1,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE TABLE IF NOT EXISTS route_candidates (
    route_id VARCHAR(64) PRIMARY KEY,
    job_id VARCHAR(64) NOT NULL REFERENCES jobs(job_id),
    route_version INTEGER NOT NULL,
    plan_epoch INTEGER NOT NULL,
    status VARCHAR(32) NOT NULL,
    operating_boundary GEOMETRY(Polygon, 4326),
    route_path GEOMETRY(MultiLineString, 4326),
    kpi_passed BOOLEAN NOT NULL DEFAULT FALSE,
    kpi_payload JSONB NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
"""


def utc_now() -> datetime:
    return datetime.now(timezone.utc)


class ExecutionState(str, Enum):
    IDLE = "IDLE"
    VALIDATING = "VALIDATING"
    PLANNING = "PLANNING"
    EVALUATING = "EVALUATING"
    AWAITING_APPROVAL = "AWAITING_APPROVAL"
    READY = "READY"
    EXECUTING = "EXECUTING"
    PAUSED = "PAUSED"
    REPLANNING = "REPLANNING"
    NEEDS_ASSISTANCE = "NEEDS_ASSISTANCE"
    COMPLETED = "COMPLETED"
    ABORTED = "ABORTED"
    EMERGENCY_STOP = "EMERGENCY_STOP"


class RouteLifecycleStatus(str, Enum):
    PROPOSED = "PROPOSED"
    DRAFT_FAILED_KPI = "DRAFT_FAILED_KPI"
    APPROVED = "APPROVED"
    EXECUTING = "EXECUTING"
    SUPERSEDED = "SUPERSEDED"
    COMPLETED = "COMPLETED"
    ABORTED = "ABORTED"


class TaskType(str, Enum):
    AREA_SWEEP = "AREA_SWEEP"
    RUBBISH_COLLECTION = "RUBBISH_COLLECTION"
    OVERSIZED_RUBBISH = "OVERSIZED_RUBBISH"
    PATROL = "PATROL"
    HYBRID = "HYBRID"


class DataProvenance(str, Enum):
    PLANNED = "PLANNED"
    ESTIMATED = "ESTIMATED"
    SIMULATED = "SIMULATED"
    MEASURED_TELEMETRY = "MEASURED_TELEMETRY"
    SYNTHETIC_FALLBACK_GRAPH = "SYNTHETIC_FALLBACK_GRAPH"


class OperatorRole(str, Enum):
    OPERATOR = "operator"
    SUPERVISOR = "supervisor"
    ADMIN = "admin"
    INTERNAL_SERVICE = "internal_service"


class Coordinate(BaseModel):
    lat: float = Field(..., ge=-90.0, le=90.0, allow_inf_nan=False)
    lon: float = Field(..., ge=-180.0, le=180.0, allow_inf_nan=False)

    def to_local_meters(self, origin: Coordinate) -> Tuple[float, float]:
        lat_rad = math.radians(origin.lat)
        x = (self.lon - origin.lon) * 111320.0 * math.cos(lat_rad)
        y = (self.lat - origin.lat) * 110540.0
        return (x, y)

    @staticmethod
    def from_local_meters(x: float, y: float, origin: Coordinate) -> Coordinate:
        lat_rad = math.radians(origin.lat)
        lon = origin.lon + x / (111320.0 * math.cos(lat_rad))
        lat = origin.lat + y / 110540.0
        return Coordinate(lat=round(lat, 7), lon=round(lon, 7))


class GeoPolygon(BaseModel):
    vertices: List[Coordinate] = Field(..., min_length=3)

    @model_validator(mode="after")
    def validate_polygon_geometry(self) -> "GeoPolygon":
        origin = self.vertices[0]
        pts = [v.to_local_meters(origin) for v in self.vertices]
        if pts[0] != pts[-1]:
            pts.append(pts[0])
        poly = Polygon(pts)
        if not poly.is_valid or poly.area < 4.0:
            raise ValueError("Invalid operating polygon: self-intersecting or area below 4.0 m^2.")
        return self

    def to_shapely_local(self, origin: Coordinate) -> Polygon:
        pts = [v.to_local_meters(origin) for v in self.vertices]
        if pts[0] != pts[-1]:
            pts.append(pts[0])
        return Polygon(pts)


class ExclusionZone(BaseModel):
    zone_id: str = Field(default_factory=lambda: f"excl-{uuid4().hex[:8]}")
    name: str = "Restricted Zone"
    reason: str = "Obstacle / Prohibited Area"
    polygon: GeoPolygon


class MachineProfile(BaseModel):
    machine_id: str
    name: str
    working_width_m: float = Field(default=1.6, gt=0.0)
    default_overlap_ratio: float = Field(default=0.12, ge=0.0, le=0.65)
    min_turning_radius_m: float = Field(default=1.2, gt=0.0)
    clearance_width_m: float = Field(default=1.4, gt=0.0)
    cruise_speed_mps: float = Field(default=1.5, gt=0.0)
    sweep_speed_mps: float = Field(default=1.0, gt=0.0)
    max_payload_kg: float = Field(default=180.0, gt=0.0)
    max_payload_volume_m3: float = Field(default=1.2, gt=0.0)
    max_item_length_m: float = Field(default=1.2, gt=0.0)
    battery_capacity_kwh: float = Field(default=12.0, gt=0.0)
    current_battery_percent: float = Field(default=95.0, ge=0.0, le=100.0)
    energy_consumption_kwh_per_km_travel: float = Field(default=0.45, ge=0.0)
    energy_consumption_kwh_per_km_sweep: float = Field(default=0.85, ge=0.0)
    has_heavy_lifter: bool = False
    has_bulky_compactor: bool = False
    current_payload_kg: float = Field(default=0.0, ge=0.0)
    current_payload_volume_m3: float = Field(default=0.0, ge=0.0)


class RubbishItemSpec(BaseModel):
    description: str = "Standard bin collection"
    is_oversized: bool = False
    estimated_weight_kg: Optional[float] = Field(default=15.0, ge=0.0)
    estimated_volume_m3: Optional[float] = Field(default=0.12, ge=0.0)
    max_dimension_m: Optional[float] = Field(default=0.6, ge=0.0)
    dimensions_uncertain: bool = False
    requires_heavy_lifter: bool = False
    weight_estimation_method: Optional[str] = None
    weight_estimation_confidence: Optional[float] = Field(default=None, ge=0.0, le=1.0)
    volume_estimation_method: Optional[str] = None
    volume_estimation_confidence: Optional[float] = Field(default=None, ge=0.0, le=1.0)
    dimension_estimation_method: Optional[str] = None
    dimension_estimation_confidence: Optional[float] = Field(default=None, ge=0.0, le=1.0)


class ImageBoundingBox(BaseModel):
    """Normalized image coordinates; never treated as a world/map position."""
    x: float = Field(ge=0.0, le=1.0)
    y: float = Field(ge=0.0, le=1.0)
    width: float = Field(gt=0.0, le=1.0)
    height: float = Field(gt=0.0, le=1.0)

    @model_validator(mode="after")
    def validate_bounds(self) -> "ImageBoundingBox":
        if self.x + self.width > 1.0 or self.y + self.height > 1.0:
            raise ValueError("Normalized image bounding box must fit within [0, 1] coordinates.")
        return self


class WasteObservation(BaseModel):
    """Optional detector report; actionability still requires a validated world location."""
    detection_id: str
    waste_class: Optional[str] = None
    confidence: Optional[float] = Field(default=None, ge=0.0, le=1.0)
    observed_at: Optional[datetime] = None
    source: Optional[str] = None
    image_bbox: Optional[ImageBoundingBox] = None
    world_location: Optional[Coordinate] = None
    rubbish_spec: Optional[RubbishItemSpec] = None


class TaskItem(BaseModel):
    task_id: str = Field(default_factory=lambda: f"task-{uuid4().hex[:8]}")
    idempotency_key: Optional[str] = None
    task_type: TaskType
    location: Coordinate
    priority: int = Field(default=5, ge=1, le=10)
    service_duration_sec: float = Field(default=60.0, ge=0.0)
    # These are elapsed mission-minute offsets, not wall-clock times.
    time_window_start_min: float = Field(default=0.0, ge=0.0)
    time_window_end_min: float = Field(default=480.0, ge=0.0)
    rubbish_spec: Optional[RubbishItemSpec] = None
    waste_observation: Optional[WasteObservation] = None
    completed: bool = False

    @model_validator(mode="after")
    def validate_time_window(self) -> "TaskItem":
        if self.time_window_end_min <= self.time_window_start_min:
            raise ValueError("Task time window end must be after its start (elapsed mission minutes).")
        return self


class TaskScheduleEntry(BaseModel):
    task_id: str
    arrival_min: float
    service_start_min: float
    service_end_min: float
    waiting_min: float
    window_start_min: float
    window_end_min: float
    priority: int
    status: str = "SCHEDULED"
    reason: Optional[str] = None
    disposal_before: bool = False


class RouteSegment(BaseModel):
    segment_id: str = Field(default_factory=lambda: f"seg-{uuid4().hex[:8]}")
    segment_type: str
    waypoints: List[Coordinate]
    distance_m: float
    estimated_duration_sec: float
    swath_width_m: float = 0.0
    target_task_id: Optional[str] = None
    provenance: DataProvenance = DataProvenance.PLANNED
    completed: bool = False


class UnreachableSection(BaseModel):
    section_id: str
    reason: str
    area_m2: float
    centroid: Coordinate


class MetricEntry(BaseModel):
    actual: float
    target: Optional[float] = None
    target_max: Optional[float] = None
    target_min: Optional[float] = None
    passed: bool
    is_constraint: bool = True
    provenance: DataProvenance = DataProvenance.ESTIMATED
    unit: str = ""


class KPIEvaluationResponse(BaseModel):
    evaluation_id: str = Field(default_factory=lambda: f"eval-{uuid4().hex[:8]}")
    route_version: int
    policy_version: str
    passed: bool
    score: float
    metrics: Dict[str, MetricEntry]
    failed_constraints: List[str]
    recommended_adjustments: List[str]
    requires_human_review: bool
    evaluated_at: datetime = Field(default_factory=utc_now)


class ReplanComparison(BaseModel):
    previous_route_id: str
    previous_route_version: int
    previous_remaining_distance_m: float
    revised_remaining_distance_m: float
    distance_delta_m: float
    previous_remaining_duration_min: float
    revised_remaining_duration_min: float
    duration_delta_min: float
    previous_coverage_percent: float
    revised_coverage_percent: float
    coverage_delta_percent: float
    previous_missed_area_m2: float
    revised_missed_area_m2: float
    missed_area_delta_m2: float
    previous_battery_percent: float
    revised_remaining_battery_percent: float
    open_collection_tasks_delta: int


class RouteCandidate(BaseModel):
    route_id: str = Field(default_factory=lambda: f"route-{uuid4().hex[:8]}")
    job_id: str
    route_version: int
    plan_epoch: int = 1
    cancellation_token: str = Field(default_factory=lambda: f"tok-{uuid4().hex[:10]}")
    machine_id: str
    status: RouteLifecycleStatus = RouteLifecycleStatus.PROPOSED
    task_mode: TaskType
    routing_provenance: DataProvenance = DataProvenance.PLANNED
    mission_elapsed_min: float = Field(default=0.0, ge=0.0, allow_inf_nan=False)
    origin: Coordinate
    disposal_depot: Coordinate
    operating_boundary: Optional[GeoPolygon] = None
    exclusion_zones: List[ExclusionZone] = Field(default_factory=list)
    tasks: List[TaskItem] = Field(default_factory=list)
    task_schedule: List[TaskScheduleEntry] = Field(default_factory=list)
    skipped_tasks: List[Dict[str, Any]] = Field(default_factory=list)
    route_safety_issues: List[str] = Field(default_factory=list)
    candidate_rationale: List[str] = Field(default_factory=list)
    deduplicated_task_ids: List[str] = Field(default_factory=list)
    segments: List[RouteSegment] = Field(default_factory=list)
    unreachable_sections: List[UnreachableSection] = Field(default_factory=list)
    target_area_m2: float = 0.0
    covered_area_m2: float = 0.0
    repeated_area_m2: float = 0.0
    missed_area_m2: float = 0.0
    sweep_angle_deg: float = 0.0
    overlap_ratio: float = 0.12
    total_distance_m: float = 0.0
    sweep_distance_m: float = 0.0
    transit_distance_m: float = 0.0
    estimated_duration_minutes: float = 0.0
    estimated_energy_kwh: float = 0.0
    estimated_remaining_battery_percent: float = 0.0
    payload_utilization_percent: float = 0.0
    disposal_trips: int = 1
    kpi_evaluation: Optional[KPIEvaluationResponse] = None
    kpi_policy_snapshot: Dict[str, Any] = Field(default_factory=dict)
    optimization_termination_reason: Optional[str] = None
    replan_reason: Optional[str] = None
    replan_comparison: Optional[ReplanComparison] = None
    approved_by: Optional[str] = None
    created_at: datetime = Field(default_factory=utc_now)


class PlanRequest(BaseModel):
    job_id: str = Field(default_factory=lambda: f"job-{uuid4().hex[:8]}")
    idempotency_key: Optional[str] = None
    natural_language_command: Optional[str] = None
    machine_id: str = "sweeper-alpha-01"
    start_location: Optional[Coordinate] = None
    disposal_location: Optional[Coordinate] = None
    mission_elapsed_min: float = Field(default=0.0, ge=0.0, allow_inf_nan=False)
    place_name: Optional[str] = None
    operating_boundary: Optional[GeoPolygon] = None
    exclusion_zones: List[ExclusionZone] = Field(default_factory=list)
    tasks: List[TaskItem] = Field(default_factory=list)
    deduplicated_task_ids: List[str] = Field(default_factory=list)
    kpi_policy_override: Optional[Dict[str, float]] = None


class OperationalEventRequest(BaseModel):
    job_id: str
    route_id: Optional[str] = None
    idempotency_key: Optional[str] = None
    detection_id: Optional[str] = None
    event_type: str
    natural_language_report: Optional[str] = None
    location: Optional[Coordinate] = None
    battery_percent: Optional[float] = Field(default=None, ge=0.0, le=100.0, allow_inf_nan=False)
    waste_observation: Optional[WasteObservation] = None
    task_id: Optional[str] = None
    task_time_window_start_min: Optional[float] = Field(default=None, ge=0.0)
    task_time_window_end_min: Optional[float] = Field(default=None, ge=0.0)
    new_operating_boundary: Optional[GeoPolygon] = None
    new_exclusion_zone: Optional[ExclusionZone] = None
    rubbish_spec: Optional[RubbishItemSpec] = None
    retain_existing_tasks: bool = True


class TelemetryFrame(BaseModel):
    telemetry_id: str = Field(default_factory=lambda: f"tel-{uuid4().hex[:8]}")
    machine_id: str
    route_id: str
    timestamp: datetime = Field(default_factory=utc_now)
    mission_elapsed_min: float = Field(default=0.0, ge=0.0, allow_inf_nan=False)
    position: Coordinate
    speed_mps: float = Field(ge=0.0)
    battery_percent: float = Field(ge=0.0, le=100.0)
    payload_kg: float = Field(ge=0.0)
    payload_volume_m3: float = Field(default=0.0, ge=0.0)
    active_segment_id: Optional[str] = None
    route_deviation_m: float = Field(default=0.0, ge=0.0)
    provenance: DataProvenance = DataProvenance.MEASURED_TELEMETRY
    sensor_fault: bool = False
    obstacle_blocked: bool = False
    emergency_stop_engaged: bool = False


class AuditEntry(BaseModel):
    audit_id: str = Field(default_factory=lambda: f"aud-{uuid4().hex[:10]}")
    timestamp: datetime = Field(default_factory=utc_now)
    job_id: str
    route_id: Optional[str] = None
    route_version: Optional[int] = None
    actor: str
    action: str
    reason: str
    details: Dict[str, Any] = Field(default_factory=dict)


class AuditAndEventManager:
    def __init__(self) -> None:
        self._audit_log: List[AuditEntry] = []
        self._idempotency_cache: Dict[str, Any] = {}

    def record(
        self,
        job_id: str,
        actor: str,
        action: str,
        reason: str,
        route_id: Optional[str] = None,
        route_version: Optional[int] = None,
        details: Optional[Dict[str, Any]] = None,
    ) -> AuditEntry:
        entry = AuditEntry(
            job_id=job_id,
            route_id=route_id,
            route_version=route_version,
            actor=actor,
            action=action,
            reason=reason,
            details=details or {},
        )
        self._audit_log.append(entry)
        return entry

    def check_idempotency(self, key: Optional[str]) -> Optional[Any]:
        return self._idempotency_cache.get(key) if key else None

    def save_idempotency(self, key: Optional[str], response_obj: Any) -> None:
        if key:
            self._idempotency_cache[key] = response_obj
