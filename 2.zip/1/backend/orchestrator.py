from __future__ import annotations

from copy import deepcopy
from time import monotonic
from typing import Dict, List, Optional

from .config import KPIPolicyConfig, settings
from .evaluator import KPIRouteQualityEvaluator
from .execution import (
    DeterministicRouteSimulator,
    ExecutionStateMachine,
    InvalidStateTransitionError,
    SafetyInterlockError,
)
from .models import (
    AuditAndEventManager,
    Coordinate,
    DataProvenance,
    ExecutionState,
    MachineProfile,
    OperationalEventRequest,
    OperatorRole,
    PlanRequest,
    RouteCandidate,
    RouteLifecycleStatus,
    ReplanComparison,
    RouteSegment,
    TaskItem,
    TaskType,
)
from .planners import CoveragePlanner, RouteOptimizationEngine, RoutingServiceUnavailableError, ValhallaRoutingService
from .validators import (
    LocationValidationError,
    MachineCapabilityValidator,
    RequestInterpreter,
    TaskAndLocationValidator,
)


class StaleRouteVersionError(Exception):
    pass


class AgenticWorkflowOrchestrator:
    """Coordinates deterministic planning, independent evaluation, and execution approval."""

    def __init__(self) -> None:
        self.audit = AuditAndEventManager()
        self.state_machine = ExecutionStateMachine(self.audit)
        self.simulator = DeterministicRouteSimulator(self.state_machine, self.audit)
        self.interpreter = RequestInterpreter()
        self.request_validator = TaskAndLocationValidator()
        self.capability_validator = MachineCapabilityValidator()
        self.coverage_planner = CoveragePlanner()
        self.routing_engine = ValhallaRoutingService()
        self.route_optimizer = RouteOptimizationEngine()
        self.evaluator = KPIRouteQualityEvaluator()
        self.machines: Dict[str, MachineProfile] = {
            "sweeper-alpha-01": MachineProfile(
                machine_id="sweeper-alpha-01", name="Compact Autonomous Sweeper Alpha-01",
                max_payload_kg=150.0, max_item_length_m=1.2,
            ),
            "heavy-utility-02": MachineProfile(
                machine_id="heavy-utility-02", name="Heavy Municipal Collector 02",
                max_payload_kg=450.0, max_payload_volume_m3=4.0,
                max_item_length_m=2.5, has_heavy_lifter=True, has_bulky_compactor=True,
            ),
        }
        self.routes_by_id: Dict[str, RouteCandidate] = {}
        self.job_route_history: Dict[str, List[RouteCandidate]] = {}
        self._latest_route_by_job: Dict[str, str] = {}
        self.simulator.latest_route_by_job = self._latest_route_by_job

    def plan_and_optimize(
        self, req: PlanRequest, actor: str = "operator",
        completed_segments: Optional[List[RouteSegment]] = None,
        replan_reason: Optional[str] = None,
    ) -> RouteCandidate:
        plan_key = f"plan:{req.job_id}:{req.idempotency_key}" if req.idempotency_key else None
        cached_plan = self.audit.check_idempotency(plan_key)
        if cached_plan is not None:
            return deepcopy(cached_plan)
        state = self.state_machine.get_state(req.job_id)
        if state == ExecutionState.EMERGENCY_STOP:
            raise SafetyInterlockError("EMERGENCY_STOP is active. A supervisor must verify a hardware reset first.")
        # Allow automatic replanning when a route is waiting for approval, ready, executing, or paused:
        if state in (
            ExecutionState.AWAITING_APPROVAL,
            ExecutionState.READY,
            ExecutionState.PAUSED,
            ExecutionState.EXECUTING,
            ExecutionState.REPLANNING,
        ):
            if state != ExecutionState.REPLANNING:
                self.state_machine.transition(req.job_id, ExecutionState.REPLANNING, actor, "Operator or auto-pilot initiated replanning")
            state = self.state_machine.transition(req.job_id, ExecutionState.VALIDATING, actor, "Validate revised planning request")
        if state not in (ExecutionState.IDLE, ExecutionState.COMPLETED, ExecutionState.ABORTED, ExecutionState.NEEDS_ASSISTANCE, ExecutionState.VALIDATING):
            raise SafetyInterlockError(f"Cannot start planning while job state is {state.value}.")

        if state != ExecutionState.VALIDATING:
            self.state_machine.transition(req.job_id, ExecutionState.VALIDATING, actor, "Validate planning request")
        if req.machine_id not in self.machines:
            self.state_machine.transition(req.job_id, ExecutionState.NEEDS_ASSISTANCE, actor, "Unknown machine profile")
            raise LocationValidationError(f"Unknown machine profile: {req.machine_id}")
        intent = self.interpreter.parse(req.natural_language_command)
        if intent.emergency_override_attempted:
            self.state_machine.transition(req.job_id, ExecutionState.NEEDS_ASSISTANCE, actor, "Unsafe override language rejected")
            raise SafetyInterlockError("Natural-language instructions cannot override safety interlocks.")
        if intent.detected_oversized_item:
            for task in req.tasks:
                if task.task_type == TaskType.OVERSIZED_RUBBISH and task.rubbish_spec is None:
                    task.rubbish_spec = intent.detected_oversized_item
        try:
            mode = self.request_validator.validate_plan_request(req, intent)
        except LocationValidationError:
            self.state_machine.transition(req.job_id, ExecutionState.NEEDS_ASSISTANCE, actor, "Planning request validation failed")
            raise
        machine = self.machines[req.machine_id]
        self.state_machine.transition(req.job_id, ExecutionState.PLANNING, actor, "Generate route candidate")

        policy = settings.kpi_policy
        if req.kpi_policy_override:
            try:
                policy = policy.model_copy(update=req.kpi_policy_override)
                policy = type(policy).model_validate(policy.model_dump())
            except Exception as exc:
                self.state_machine.transition(req.job_id, ExecutionState.NEEDS_ASSISTANCE, actor, "Invalid KPI policy override")
                raise LocationValidationError(f"Invalid KPI policy override: {exc}") from exc

        started = monotonic()
        history = self.job_route_history.setdefault(req.job_id, [])
        previous_latest_id = self._latest_route_by_job.get(req.job_id)
        previous_route = self.routes_by_id.get(previous_latest_id) if previous_latest_id else None
        best: Optional[RouteCandidate] = None
        final = None
        angles = settings.optimization.candidate_sweep_angles_deg
        for iteration in range(settings.optimization.max_iterations):
            if monotonic() - started > settings.optimization.timeout_seconds:
                break
            if self.state_machine.get_state(req.job_id) != ExecutionState.PLANNING:
                self.state_machine.transition(req.job_id, ExecutionState.PLANNING, actor, "Continue bounded optimization")
            try:
                candidate = self._make_candidate(
                    req, mode, machine, history, iteration, angles, completed_segments, replan_reason
                )
            except RoutingServiceUnavailableError:
                self.state_machine.transition(req.job_id, ExecutionState.NEEDS_ASSISTANCE, actor, "Required routing service unavailable")
                raise
            except Exception:
                self.state_machine.transition(req.job_id, ExecutionState.NEEDS_ASSISTANCE, actor, "Candidate generation failed")
                raise
            self.state_machine.transition(req.job_id, ExecutionState.EVALUATING, actor, "Independently evaluate route metrics")
            try:
                candidate.kpi_policy_snapshot = policy.model_dump()
                candidate.kpi_evaluation = self.evaluator.evaluate(candidate, machine, policy)
            except Exception:
                self.state_machine.transition(req.job_id, ExecutionState.NEEDS_ASSISTANCE, actor, "KPI evaluation failed")
                raise
            candidate.status = (
                RouteLifecycleStatus.PROPOSED
                if candidate.kpi_evaluation.passed
                else RouteLifecycleStatus.DRAFT_FAILED_KPI
            )
            candidate.candidate_rationale.append(
                f"KPI score {candidate.kpi_evaluation.score:.2f}; "
                + ("all configured constraints passed." if candidate.kpi_evaluation.passed else
                   "failed constraints: " + ", ".join(candidate.kpi_evaluation.failed_constraints) + ".")
            )
            candidate.optimization_termination_reason = "acceptance_criteria_passed" if candidate.kpi_evaluation.passed else None
            if previous_route is not None and replan_reason is not None:
                candidate.replan_comparison = self._compare_replan(
                    previous_route, candidate, machine.current_battery_percent
                )
            self._store_candidate(candidate)
            history.append(candidate)
            final = candidate
            if best is None or candidate.kpi_evaluation.score > (best.kpi_evaluation.score if best.kpi_evaluation else -1):
                best = candidate
            if candidate.kpi_evaluation.passed:
                self.state_machine.transition(req.job_id, ExecutionState.AWAITING_APPROVAL, actor, "Candidate passed KPI policy")
                if plan_key:
                    self.audit.save_idempotency(plan_key, deepcopy(candidate))
                return candidate
            if iteration + 1 < settings.optimization.max_iterations:
                self.state_machine.transition(req.job_id, ExecutionState.PLANNING, actor, "Revise candidate using evaluator feedback")

        result = best or final
        if result is None:
            self.state_machine.transition(req.job_id, ExecutionState.NEEDS_ASSISTANCE, actor, "No candidate could be produced")
            raise LocationValidationError("No route candidate could be produced.")
        result.optimization_termination_reason = (
            "optimization_timeout" if monotonic() - started > settings.optimization.timeout_seconds
            else "iteration_limit_reached"
        )
        if final is not None and result.route_id != final.route_id:
            final.status = RouteLifecycleStatus.SUPERSEDED
            result.status = RouteLifecycleStatus.DRAFT_FAILED_KPI
            self._latest_route_by_job[req.job_id] = result.route_id
        if result.status == RouteLifecycleStatus.PROPOSED:
            self.state_machine.transition(req.job_id, ExecutionState.AWAITING_APPROVAL, actor, result.optimization_termination_reason)
        else:
            self.state_machine.transition(req.job_id, ExecutionState.NEEDS_ASSISTANCE, actor, result.optimization_termination_reason)
        if plan_key:
            self.audit.save_idempotency(plan_key, deepcopy(result))
        return result

    def _make_candidate(
        self, req: PlanRequest, mode: TaskType, machine: MachineProfile,
        history: List[RouteCandidate], iteration: int, angles: List[float],
        completed_segments: Optional[List[RouteSegment]] = None,
        replan_reason: Optional[str] = None,
    ) -> RouteCandidate:
        assert req.start_location is not None and req.disposal_location is not None
        tasks = deepcopy(req.tasks)
        feasible_tasks, rejected, trips = self.capability_validator.validate_task_batch(machine, tasks)
        skipped = [
            {"task_id": task.task_id, "reasons": check.rejection_reasons, "recommended_actions": check.recommended_actions}
            for task, check in rejected
        ]
        version = (history[-1].route_version + 1) if history else 1
        segments: List[RouteSegment] = deepcopy([
            segment for segment in (completed_segments or []) if segment.completed
        ])
        routing_provenance = DataProvenance.PLANNED
        target_area = covered_area = repeated_area = missed_area = sweep_distance = transit_distance = 0.0
        task_schedule = []
        route_safety_issues: List[str] = []
        scheduled_task_order: List[TaskItem] = []
        angle = angles[(iteration // 2) % len(angles)] if angles else 0.0
        overlap = min(
            0.65,
            machine.default_overlap_ratio + (iteration % 2) * settings.optimization.overlap_step_increment,
        )
        candidate_rationale = [
            f"Bounded deterministic candidate {iteration + 1}: sweep angle {angle:.1f} degrees, "
            f"overlap {overlap:.2f}."
        ]
        if req.deduplicated_task_ids:
            candidate_rationale.append(
                f"Duplicate task reports were removed by idempotency key: {', '.join(req.deduplicated_task_ids)}."
            )

        if mode in (TaskType.AREA_SWEEP, TaskType.PATROL, TaskType.HYBRID):
            assert req.operating_boundary is not None
            coverage = self.coverage_planner.plan_coverage(
                req.operating_boundary, req.exclusion_zones, machine,
                sweep_angle_deg=angle, overlap_ratio=overlap, completed_segments=completed_segments,
            )
            existing_segment_ids = {segment.segment_id for segment in segments}
            segments.extend(
                segment for segment in coverage.segments
                if segment.segment_id not in existing_segment_ids
            )
            target_area, covered_area = coverage.target_area_m2, coverage.covered_area_m2
            repeated_area, missed_area = coverage.repeated_area_m2, coverage.missed_area_m2
            route_safety_issues.extend(coverage.route_safety_issues)

            remaining_sweep_segments = [
                segment for segment in coverage.segments
                if segment.segment_type == "SWEEP_SWATH" and not segment.completed and segment.waypoints
            ]
            if remaining_sweep_segments:
                first_point = remaining_sweep_segments[0].waypoints[0]
                last_point = remaining_sweep_segments[-1].waypoints[-1]
                ingress_matrix, ingress_paths = self.routing_engine.compute_matrix_and_paths(
                    [req.start_location, first_point], machine.cruise_speed_mps
                )
                ingress = ingress_paths.get((0, 1), [])
                if len(ingress) >= 2:
                    ingress_distance = ingress_matrix.distance_matrix_m[0][1]
                    if ingress_distance > 0.5:
                        segments.insert(0, RouteSegment(
                            segment_type="TRANSIT", waypoints=ingress,
                            distance_m=round(ingress_distance, 2),
                            estimated_duration_sec=round(ingress_matrix.duration_matrix_sec[0][1], 2),
                            provenance=ingress_matrix.provenance,
                        ))
                        transit_distance += ingress_distance
                        routing_provenance = ingress_matrix.provenance
                if mode != TaskType.HYBRID:
                    egress_matrix, egress_paths = self.routing_engine.compute_matrix_and_paths(
                        [last_point, req.disposal_location], machine.cruise_speed_mps
                    )
                    egress = egress_paths.get((0, 1), [])
                    if len(egress) >= 2:
                        egress_distance = egress_matrix.distance_matrix_m[0][1]
                        if egress_distance > 0.5:
                            segments.append(RouteSegment(
                                segment_type="RETURN_TO_BASE", waypoints=egress,
                                distance_m=round(egress_distance, 2),
                                estimated_duration_sec=round(egress_matrix.duration_matrix_sec[0][1], 2),
                                provenance=egress_matrix.provenance,
                            ))
                            transit_distance += egress_distance
                            routing_provenance = egress_matrix.provenance

        if mode in (TaskType.RUBBISH_COLLECTION, TaskType.OVERSIZED_RUBBISH, TaskType.HYBRID):
            tasks_to_route = [t for t in feasible_tasks if not t.completed]
            if tasks_to_route:
                collection_start = req.start_location
                if mode == TaskType.HYBRID and segments:
                    last_sweep_segment = next(
                        (segment for segment in reversed(segments) if segment.waypoints), None
                    )
                    if last_sweep_segment is not None:
                        collection_start = last_sweep_segment.waypoints[-1]
                locations = [collection_start] + [t.location for t in tasks_to_route] + [req.disposal_location]
                matrix, paths = self.routing_engine.compute_matrix_and_paths(locations, machine.cruise_speed_mps)
                routing_provenance = matrix.provenance
                plan = self.route_optimizer.optimize_collection_route(
                    collection_start, req.disposal_location, tasks_to_route, machine,
                    matrix.distance_matrix_m, matrix.duration_matrix_sec, paths, matrix.provenance,
                    start_elapsed_min=req.mission_elapsed_min + sum(
                        s.estimated_duration_sec for s in segments if not s.completed
                    ) / 60.0,
                )
                segments.extend(plan.segments)
                transit_distance += plan.total_transit_distance_m
                trips = plan.disposal_trips
                task_schedule = plan.task_schedule
                scheduled_task_order = plan.ordered_tasks
                for task in plan.skipped_optional_tasks:
                    skipped.append({
                        "task_id": task.task_id,
                        "reasons": ["task_time_window_infeasible"],
                        "recommended_actions": ["Adjust its elapsed mission-minute window or revise the mission schedule."],
                    })
                if plan.skipped_optional_tasks:
                    candidate_rationale.append(
                        "The time-window scheduler left infeasible tasks unassigned and reported them for operator review."
                    )
                candidate_rationale.append(
                    f"Collection order honors task priority, travel time, service duration, time windows, and depot trips ({plan.disposal_trips})."
                )

        sweep_distance = sum(
            segment.distance_m for segment in segments
            if not segment.completed and segment.segment_type in {"SWEEP_SWATH", "TURN_CONNECTOR"}
        )
        transit_distance = sum(
            segment.distance_m for segment in segments
            if not segment.completed and segment.segment_type in {"TRANSIT", "RETURN_TO_BASE"}
        )
        total_distance = sweep_distance + transit_distance
        total_seconds = sum(seg.estimated_duration_sec for seg in segments if not seg.completed)
        energy = (sweep_distance / 1000.0 * machine.energy_consumption_kwh_per_km_sweep
                  + transit_distance / 1000.0 * machine.energy_consumption_kwh_per_km_travel)
        battery_spent_pct = energy / max(machine.battery_capacity_kwh, 0.01) * 100.0
        payload_kg = machine.current_payload_kg + sum(
            t.rubbish_spec.estimated_weight_kg or 0.0
            for t in feasible_tasks if t.rubbish_spec and not t.completed
        )
        payload_volume = machine.current_payload_volume_m3 + sum(
            t.rubbish_spec.estimated_volume_m3 or 0.0
            for t in feasible_tasks if t.rubbish_spec and not t.completed
        )
        if mode in (TaskType.RUBBISH_COLLECTION, TaskType.OVERSIZED_RUBBISH, TaskType.HYBRID) and tasks_to_route:
            payload_kg = plan.peak_payload_kg
            payload_volume = plan.peak_payload_volume_m3
        payload_pct = max(
            payload_kg / max(machine.max_payload_kg, 0.01) * 100.0,
            payload_volume / max(machine.max_payload_volume_m3, 0.01) * 100.0,
        )
        scheduled_ids = {t.task_id for t in scheduled_task_order}
        candidate_tasks = (
            list(scheduled_task_order)
            + [t for t in feasible_tasks if t.task_id not in scheduled_ids]
            + [t for t, _ in rejected]
        )
        candidate = RouteCandidate(
            job_id=req.job_id, route_version=version, plan_epoch=version, machine_id=machine.machine_id,
            task_mode=mode, routing_provenance=routing_provenance,
            mission_elapsed_min=req.mission_elapsed_min,
            origin=req.start_location, disposal_depot=req.disposal_location,
            operating_boundary=req.operating_boundary, exclusion_zones=req.exclusion_zones,
            tasks=candidate_tasks, task_schedule=task_schedule, skipped_tasks=skipped, segments=segments,
            route_safety_issues=route_safety_issues, candidate_rationale=candidate_rationale,
            deduplicated_task_ids=req.deduplicated_task_ids,
            replan_reason=replan_reason,
            unreachable_sections=coverage.unreachable_sections if mode in (TaskType.AREA_SWEEP, TaskType.PATROL, TaskType.HYBRID) else [],
            target_area_m2=target_area, covered_area_m2=covered_area, repeated_area_m2=repeated_area,
            missed_area_m2=missed_area, sweep_angle_deg=angle, overlap_ratio=overlap,
            total_distance_m=total_distance, sweep_distance_m=sweep_distance, transit_distance_m=transit_distance,
            estimated_duration_minutes=total_seconds / 60.0, estimated_energy_kwh=energy,
            estimated_remaining_battery_percent=max(0.0, machine.current_battery_percent - battery_spent_pct),
            payload_utilization_percent=payload_pct, disposal_trips=trips,
        )
        geometry_issues = self.request_validator.validate_route_geometry(candidate, machine)
        candidate.route_safety_issues = list(dict.fromkeys(candidate.route_safety_issues + geometry_issues))
        if candidate.route_safety_issues:
            candidate_rationale.append("One or more route sections failed geometry checks and cannot be approved.")
        return candidate

    def _store_candidate(self, candidate: RouteCandidate) -> None:
        previous_id = self._latest_route_by_job.get(candidate.job_id)
        if previous_id and previous_id in self.routes_by_id:
            previous = self.routes_by_id[previous_id]
            if previous.status not in (RouteLifecycleStatus.COMPLETED, RouteLifecycleStatus.ABORTED):
                previous.status = RouteLifecycleStatus.SUPERSEDED
        self.routes_by_id[candidate.route_id] = candidate
        self._latest_route_by_job[candidate.job_id] = candidate.route_id

    def refresh_route_evaluation(self, route: RouteCandidate) -> RouteCandidate:
        """Recompute the evaluator view using this route's original policy and telemetry."""
        machine = self.machines[route.machine_id]
        policy = KPIPolicyConfig.model_validate(
            route.kpi_policy_snapshot or settings.kpi_policy.model_dump()
        )
        frames = self.simulator.telemetry_store.get(route.route_id, [])
        route.kpi_evaluation = self.evaluator.evaluate(route, machine, policy, frames)
        return route

    @staticmethod
    def _coverage_percent(route: RouteCandidate) -> float:
        if route.target_area_m2 <= 0.0:
            return 100.0
        return round(min(100.0, route.covered_area_m2 / route.target_area_m2 * 100.0), 2)

    def _compare_replan(
        self, previous: RouteCandidate, revised: RouteCandidate, previous_battery_percent: float,
    ) -> ReplanComparison:
        previous_remaining = [segment for segment in previous.segments if not segment.completed]
        previous_distance = sum(segment.distance_m for segment in previous_remaining)
        previous_duration = sum(segment.estimated_duration_sec for segment in previous_remaining) / 60.0
        revised_open_tasks = sum(
            not task.completed and task.task_type in (TaskType.RUBBISH_COLLECTION, TaskType.OVERSIZED_RUBBISH)
            for task in revised.tasks
        )
        previous_open_tasks = sum(
            not task.completed and task.task_type in (TaskType.RUBBISH_COLLECTION, TaskType.OVERSIZED_RUBBISH)
            for task in previous.tasks
        )
        previous_coverage = self._coverage_percent(previous)
        revised_coverage = self._coverage_percent(revised)
        return ReplanComparison(
            previous_route_id=previous.route_id,
            previous_route_version=previous.route_version,
            previous_remaining_distance_m=round(previous_distance, 2),
            revised_remaining_distance_m=revised.total_distance_m,
            distance_delta_m=round(revised.total_distance_m - previous_distance, 2),
            previous_remaining_duration_min=round(previous_duration, 2),
            revised_remaining_duration_min=revised.estimated_duration_minutes,
            duration_delta_min=round(revised.estimated_duration_minutes - previous_duration, 2),
            previous_coverage_percent=previous_coverage,
            revised_coverage_percent=revised_coverage,
            coverage_delta_percent=round(revised_coverage - previous_coverage, 2),
            previous_missed_area_m2=previous.missed_area_m2,
            revised_missed_area_m2=revised.missed_area_m2,
            missed_area_delta_m2=round(revised.missed_area_m2 - previous.missed_area_m2, 2),
            previous_battery_percent=round(previous_battery_percent, 2),
            revised_remaining_battery_percent=revised.estimated_remaining_battery_percent,
            open_collection_tasks_delta=revised_open_tasks - previous_open_tasks,
        )

    def approve_route(self, route_id: str, actor: str, role: OperatorRole) -> RouteCandidate:
        if role not in (OperatorRole.OPERATOR, OperatorRole.SUPERVISOR, OperatorRole.ADMIN):
            raise PermissionError("An operator role is required to approve routes.")
        route = self.routes_by_id.get(route_id)
        if route is None:
            raise KeyError("Route not found")
        if self._latest_route_by_job.get(route.job_id) != route_id or route.status != RouteLifecycleStatus.PROPOSED:
            raise StaleRouteVersionError("Only the latest candidate that passed KPI evaluation can be approved.")
        if not route.kpi_evaluation or not route.kpi_evaluation.passed:
            raise SafetyInterlockError("Candidate did not pass mandatory KPI criteria.")
        if route.route_safety_issues or route.unreachable_sections:
            raise SafetyInterlockError("Candidate contains unresolved route geometry.")
        route.status = RouteLifecycleStatus.APPROVED
        route.approved_by = actor
        self.state_machine.transition(route.job_id, ExecutionState.READY, actor, "Operator approved route", role=role, mandatory_constraints_passed=True)
        self.audit.record(route.job_id, actor, "APPROVE_ROUTE", "Approved KPI-passing route", route_id, route.route_version)
        return route

    def handle_operational_event(
        self, event: OperationalEventRequest, actor: str = "operator", role: OperatorRole = OperatorRole.OPERATOR,
    ) -> Dict[str, object]:
        kind = event.event_type.upper()
        observation_id = event.waste_observation.detection_id if event.waste_observation else None
        dedupe_value = event.idempotency_key or event.detection_id or observation_id
        event_key = f"event:{event.job_id}:{dedupe_value}" if dedupe_value else None
        cached_event = self.audit.check_idempotency(event_key)
        if cached_event is not None:
            return deepcopy(cached_event)

        def finish(result: Dict[str, object]) -> Dict[str, object]:
            if event_key:
                self.audit.save_idempotency(event_key, deepcopy(result))
            return result

        route = self.routes_by_id.get(event.route_id) if event.route_id else None
        if route is None:
            rid = self._latest_route_by_job.get(event.job_id)
            route = self.routes_by_id.get(rid) if rid else None
        if kind == "EMERGENCY_STOP":
            current = self.state_machine.get_state(event.job_id)
            if current != ExecutionState.EMERGENCY_STOP:
                self.state_machine.transition(event.job_id, ExecutionState.EMERGENCY_STOP, actor, "Emergency stop event", role=role)
            return finish({"state": ExecutionState.EMERGENCY_STOP.value})
        if event.route_id and self._latest_route_by_job.get(event.job_id) != event.route_id:
            raise StaleRouteVersionError("Operational event references a stale route version.")
        if kind in {"SENSOR_FAULT", "FULL_PAYLOAD"} or (
            kind == "OBSTACLE_DETECTED" and event.new_exclusion_zone is None
        ) or (kind == "LOW_BATTERY" and route is None):
            current = self.state_machine.get_state(event.job_id)
            if current not in (ExecutionState.EMERGENCY_STOP, ExecutionState.NEEDS_ASSISTANCE):
                self.state_machine.transition(event.job_id, ExecutionState.NEEDS_ASSISTANCE, actor, f"Operational event: {kind}", role=role)
            result = {"state": self.state_machine.get_state(event.job_id).value, "event_type": kind}
            if kind == "OBSTACLE_DETECTED":
                result["replan_blocked_reason"] = "A validated obstacle exclusion polygon is required before replanning."
            return finish(result)
        if not route and kind == "LOCATION_CHANGE" and event.new_operating_boundary is not None:
            req_initial = PlanRequest(
                job_id=event.job_id,
                machine_id="sweeper-alpha-01",
                operating_boundary=event.new_operating_boundary,
                exclusion_zones=[event.new_exclusion_zone] if event.new_exclusion_zone else [],
            )
            candidate_init = self.plan_and_optimize(
                req_initial, actor=actor, replan_reason="operating_boundary_changed"
            )
            return finish({"state": self.state_machine.get_state(event.job_id).value, "candidate": candidate_init})
        if not route:
            raise LocationValidationError("No existing route was found for this operational event.")
        if kind == "LOCATION_CHANGE" and event.new_operating_boundary is None:
            raise LocationValidationError("Location change requires a new operating boundary.")
        if kind == "OBSTACLE_DETECTED" and event.new_exclusion_zone is None:
            raise LocationValidationError("Obstacle replanning requires a validated exclusion polygon.")
        if kind not in {
            "LOCATION_CHANGE", "OVERSIZED_RUBBISH", "MISSED_COLLECTION",
            "TIME_WINDOW_CHANGED", "ROUTE_DEVIATION", "HIGH_ROUTE_DEVIATION", "OBSTACLE_DETECTED",
            "LOW_BATTERY",
        }:
            raise LocationValidationError(f"Unsupported operational event type: {kind}.")

        if kind == "LOW_BATTERY":
            machine = self.machines[route.machine_id]
            if event.battery_percent is not None:
                machine.current_battery_percent = event.battery_percent
            elif not self.simulator.telemetry_store.get(route.route_id):
                current = self.state_machine.get_state(event.job_id)
                if current not in (ExecutionState.EMERGENCY_STOP, ExecutionState.NEEDS_ASSISTANCE):
                    self.state_machine.transition(
                        event.job_id, ExecutionState.NEEDS_ASSISTANCE, actor,
                        "Low-battery report had no current measured battery value",
                        role=role,
                    )
                return finish({
                    "state": self.state_machine.get_state(event.job_id).value,
                    "event_type": kind,
                    "replan_blocked_reason": "A measured battery percentage is required to evaluate the remaining mission.",
                })

        tasks = [deepcopy(t) for t in route.tasks if event.retain_existing_tasks]
        if kind == "OVERSIZED_RUBBISH":
            observation = event.waste_observation
            if (
                event.location is not None and observation is not None
                and observation.world_location is not None
                and event.location != observation.world_location
            ):
                raise LocationValidationError("Conflicting event and observation world locations were supplied.")
            location = event.location or (observation.world_location if observation else None)
            if location is None:
                raise LocationValidationError("An oversized collection report requires a location.")
            spec = event.rubbish_spec or (observation.rubbish_spec if observation else None)
            if spec is None and event.natural_language_report:
                spec = self.interpreter.parse(event.natural_language_report).detected_oversized_item
            if spec is None:
                from .models import RubbishItemSpec
                spec = RubbishItemSpec(is_oversized=True, dimensions_uncertain=True, estimated_weight_kg=None, estimated_volume_m3=None)
            stored_observation = deepcopy(observation) if observation else None
            if stored_observation and stored_observation.world_location is None:
                stored_observation.world_location = location
            tasks.append(TaskItem(
                task_type=TaskType.OVERSIZED_RUBBISH, location=location, priority=10,
                rubbish_spec=spec, waste_observation=stored_observation,
                idempotency_key=dedupe_value,
            ))
        elif kind == "MISSED_COLLECTION":
            if not event.task_id:
                raise LocationValidationError("A missed-collection event requires task_id.")
            task = next((deepcopy(t) for t in route.tasks if t.task_id == event.task_id), None)
            if task is None:
                raise LocationValidationError(f"Unknown collection task: {event.task_id}.")
            task.completed = False
            if all(t.task_id != task.task_id for t in tasks):
                tasks.append(task)
            else:
                tasks = [task if t.task_id == task.task_id else t for t in tasks]
        elif kind == "TIME_WINDOW_CHANGED":
            if not event.task_id or event.task_time_window_start_min is None or event.task_time_window_end_min is None:
                raise LocationValidationError("Time-window changes require task_id and both elapsed-minute bounds.")
            task = next((deepcopy(t) for t in route.tasks if t.task_id == event.task_id), None)
            if task is None:
                raise LocationValidationError(f"Unknown collection task: {event.task_id}.")
            task.time_window_start_min = event.task_time_window_start_min
            task.time_window_end_min = event.task_time_window_end_min
            task = TaskItem.model_validate(task.model_dump())
            if all(t.task_id != task.task_id for t in tasks):
                tasks.append(task)
            else:
                tasks = [task if t.task_id == task.task_id else t for t in tasks]
        elif kind in {"ROUTE_DEVIATION", "HIGH_ROUTE_DEVIATION"} and event.location is None:
            raise LocationValidationError("A route-deviation event requires the measured machine location.")

        current = self.state_machine.get_state(event.job_id)
        if current in (ExecutionState.READY, ExecutionState.EXECUTING, ExecutionState.PAUSED, ExecutionState.AWAITING_APPROVAL):
            self.state_machine.transition(event.job_id, ExecutionState.REPLANNING, actor, f"Replan after {kind}", role=role)
            self.state_machine.transition(event.job_id, ExecutionState.VALIDATING, actor, "Validate event-driven plan", role=role)
        elif current == ExecutionState.NEEDS_ASSISTANCE:
            self.state_machine.transition(event.job_id, ExecutionState.VALIDATING, actor, "Validate event-driven plan", role=role)
        elif current == ExecutionState.IDLE:
            self.state_machine.transition(event.job_id, ExecutionState.VALIDATING, actor, "Validate event-driven plan", role=role)
        new_boundary = event.new_operating_boundary or route.operating_boundary
        boundary_unchanged = (
            event.new_operating_boundary is None
            or event.new_operating_boundary == route.operating_boundary
        )
        previous_frames = self.simulator.telemetry_store.get(route.route_id, [])
        current_position = (
            event.location if kind in {"ROUTE_DEVIATION", "HIGH_ROUTE_DEVIATION"} and event.location
            else previous_frames[-1].position if previous_frames else route.origin
        )
        mission_elapsed_min = (
            previous_frames[-1].mission_elapsed_min
            if previous_frames else route.mission_elapsed_min + sum(
                segment.estimated_duration_sec for segment in route.segments if segment.completed
            ) / 60.0
        )
        req = PlanRequest(
            job_id=event.job_id, machine_id=route.machine_id, start_location=current_position,
            mission_elapsed_min=mission_elapsed_min,
            disposal_location=route.disposal_depot,
            operating_boundary=new_boundary,
            exclusion_zones=route.exclusion_zones + ([event.new_exclusion_zone] if event.new_exclusion_zone else []),
            tasks=tasks,
        )
        candidate = self.plan_and_optimize(
            req, actor=actor, completed_segments=route.segments if boundary_unchanged else None,
            replan_reason=(
                "obstacle_report_with_validated_exclusion" if kind == "OBSTACLE_DETECTED"
                else "new_validated_waste_location" if kind == "OVERSIZED_RUBBISH"
                else "missed_collection" if kind == "MISSED_COLLECTION"
                else "task_time_window_changed" if kind == "TIME_WINDOW_CHANGED"
                else "high_route_deviation" if kind in {"ROUTE_DEVIATION", "HIGH_ROUTE_DEVIATION"}
                else "low_battery_remaining_mission" if kind == "LOW_BATTERY"
                else "operating_boundary_changed"
            ),
        )
        previous_battery = (
            event.battery_percent if event.battery_percent is not None
            else previous_frames[-1].battery_percent if previous_frames
            else route.estimated_remaining_battery_percent
        )
        candidate.replan_comparison = self._compare_replan(route, candidate, previous_battery)
        candidate.candidate_rationale.append(
            f"Compared with route v{route.route_version}, remaining distance changed by "
            f"{candidate.replan_comparison.distance_delta_m:+.1f} m and remaining time by "
            f"{candidate.replan_comparison.duration_delta_min:+.1f} min."
        )
        self.audit.record(
            event.job_id, actor, f"EVENT:{kind}", "Operational event caused route revision",
            candidate.route_id, candidate.route_version,
            details={
                "detection_id": observation_id,
                "observation_source": event.waste_observation.source if event.waste_observation else None,
            },
        )
        return finish({"state": self.state_machine.get_state(event.job_id).value, "candidate": candidate})