from typing import Dict, List, Optional
from .config import KPIPolicyConfig
from .models import (
    DataProvenance,
    KPIEvaluationResponse,
    MachineProfile,
    MetricEntry,
    RouteCandidate,
    TaskType,
    TelemetryFrame,
)


class KPIRouteQualityEvaluator:
    def evaluate(
        self,
        candidate: RouteCandidate,
        machine: MachineProfile,
        policy: KPIPolicyConfig,
        telemetry_history: Optional[List[TelemetryFrame]] = None,
    ) -> KPIEvaluationResponse:
        metrics: Dict[str, MetricEntry] = {}
        failed: List[str] = []
        recs: List[str] = []
        human_review = False
        # These candidate values are forecasts. Telemetry can inform a separate
        # actuals report, but must never relabel planned estimates as measured.
        prov = DataProvenance.ESTIMATED

        if candidate.task_mode in (TaskType.AREA_SWEEP, TaskType.PATROL, TaskType.HYBRID):
            cov = (
                round(min(100.0, (candidate.covered_area_m2 / candidate.target_area_m2) * 100.0), 2)
                if candidate.target_area_m2 > 0
                else 0.0
            )
            cov_ok = cov >= policy.min_coverage_percent
            metrics["coverage_percent"] = MetricEntry(
                actual=cov, target=policy.min_coverage_percent, passed=cov_ok, provenance=DataProvenance.PLANNED, unit="%"
            )
            if not cov_ok:
                failed.append("coverage_below_target")
                recs.append("Increase swath overlap ratio or adjust sweep angle.")

            missed_pct = max(0.0, 100.0 - cov)
            missed_ok = missed_pct <= policy.max_missed_coverage_percent
            metrics["missed_coverage_percent"] = MetricEntry(
                actual=round(missed_pct, 2), target_max=policy.max_missed_coverage_percent,
                passed=missed_ok, provenance=DataProvenance.PLANNED, unit="%"
            )
            if not missed_ok:
                failed.append("missed_coverage_exceeds_limit")

            repeated_pct = (
                min(100.0, candidate.repeated_area_m2 / max(candidate.target_area_m2, 0.01) * 100.0)
            )
            repeated_ok = repeated_pct <= policy.max_repeated_coverage_percent
            metrics["repeated_coverage_percent"] = MetricEntry(
                actual=round(repeated_pct, 2), target_max=policy.max_repeated_coverage_percent,
                passed=repeated_ok, provenance=DataProvenance.PLANNED, unit="%"
            )
            if not repeated_ok:
                failed.append("repeated_coverage_exceeds_limit")

        dur_ok = candidate.estimated_duration_minutes <= policy.max_estimated_duration_minutes
        metrics["estimated_duration_minutes"] = MetricEntry(
            actual=candidate.estimated_duration_minutes,
            target_max=policy.max_estimated_duration_minutes,
            passed=dur_ok,
            provenance=prov,
            unit="min",
        )
        if not dur_ok:
            failed.append("duration_exceeds_target_max")

        window_misses = [
            item for item in candidate.skipped_tasks
            if "task_time_window_infeasible" in item.get("reasons", [])
        ]
        window_ok = len(window_misses) == 0
        metrics["time_window_violations"] = MetricEntry(
            actual=float(len(window_misses)), target_max=0.0, passed=window_ok,
            provenance=DataProvenance.PLANNED, unit="tasks",
        )
        if not window_ok:
            failed.append("task_time_window_infeasible")

        geometry_ok = not candidate.route_safety_issues and not candidate.unreachable_sections
        metrics["route_geometry_issues"] = MetricEntry(
            actual=float(len(candidate.route_safety_issues) + len(candidate.unreachable_sections)),
            target_max=0.0, passed=geometry_ok, provenance=DataProvenance.PLANNED, unit="sections",
        )
        if not geometry_ok:
            failed.append("route_geometry_unresolved")

        frames = telemetry_history or []
        telemetry_provenance = (
            DataProvenance.MEASURED_TELEMETRY
            if any(frame.provenance == DataProvenance.MEASURED_TELEMETRY for frame in frames)
            else DataProvenance.SIMULATED if frames else prov
        )
        max_deviation = max((frame.route_deviation_m for frame in frames), default=0.0)
        obstacle_count = sum(frame.obstacle_blocked for frame in frames)
        deviation_ok = max_deviation <= policy.max_route_deviation_m
        metrics["max_route_deviation_m"] = MetricEntry(
            actual=round(max_deviation, 2), target_max=policy.max_route_deviation_m,
            passed=deviation_ok, provenance=telemetry_provenance, unit="m",
        )
        obstacle_ok = obstacle_count == 0
        metrics["obstacle_events"] = MetricEntry(
            actual=float(obstacle_count), target_max=0.0, passed=obstacle_ok,
            provenance=telemetry_provenance, unit="events",
        )
        if not deviation_ok:
            failed.append("route_deviation_exceeds_limit")
        if not obstacle_ok:
            failed.append("obstacle_event_requires_replan")

        batt_ok = candidate.estimated_remaining_battery_percent >= policy.min_energy_reserve_percent
        metrics["remaining_energy_reserve_percent"] = MetricEntry(
            actual=candidate.estimated_remaining_battery_percent,
            target_min=policy.min_energy_reserve_percent,
            passed=batt_ok,
            provenance=prov,
            unit="%",
        )
        if not batt_ok:
            failed.append("energy_reserve_below_minimum")

        distance_ok = candidate.total_distance_m <= policy.max_travel_distance_m
        metrics["total_distance_m"] = MetricEntry(
            actual=candidate.total_distance_m, target_max=policy.max_travel_distance_m,
            passed=distance_ok, provenance=DataProvenance.ESTIMATED, unit="m"
        )
        if not distance_ok:
            failed.append("travel_distance_exceeds_limit")

        payload_ok = candidate.payload_utilization_percent <= policy.max_payload_utilization_percent
        metrics["payload_utilization_percent"] = MetricEntry(
            actual=candidate.payload_utilization_percent, target_max=policy.max_payload_utilization_percent,
            passed=payload_ok, provenance=DataProvenance.ESTIMATED, unit="%"
        )
        if not payload_ok:
            failed.append("payload_utilization_exceeds_limit")

        collection_tasks = [
            t for t in candidate.tasks
            if t.task_type in (TaskType.RUBBISH_COLLECTION, TaskType.OVERSIZED_RUBBISH)
        ]
        task_ids = {t.task_id for t in collection_tasks}
        task_ids.update(item.get("task_id", "") for item in candidate.skipped_tasks)
        task_ids.discard("")
        assigned_ids = {entry.task_id for entry in candidate.task_schedule}
        assigned_ids.update(task.task_id for task in collection_tasks if task.completed)
        assigned_count = len(task_ids.intersection(assigned_ids))
        total_collection_tasks = len(task_ids)
        assignment_percent = (
            100.0 if total_collection_tasks == 0
            else 100.0 * assigned_count / total_collection_tasks
        )
        collection_ok = assignment_percent >= policy.required_collection_completion_rate
        assignment_metric = MetricEntry(
            actual=assignment_percent, target=policy.required_collection_completion_rate,
            passed=collection_ok, provenance=DataProvenance.PLANNED, unit="%",
        )
        metrics["planned_collection_assignment_percent"] = assignment_metric
        # Keep the original metric key for API clients that predate the clearer name.
        metrics["collection_completion_percent"] = assignment_metric.model_copy(deep=True)
        completed_count = sum(task.task_id in task_ids and task.completed for task in collection_tasks)
        simulated_completion = (
            100.0 if total_collection_tasks == 0
            else 100.0 * completed_count / total_collection_tasks
        )
        metrics["simulated_collection_completion_percent"] = MetricEntry(
            actual=simulated_completion,
            target=policy.required_collection_completion_rate,
            passed=simulated_completion >= policy.required_collection_completion_rate,
            is_constraint=False,
            provenance=(
                DataProvenance.SIMULATED if any(frame.provenance == DataProvenance.SIMULATED for frame in frames)
                else DataProvenance.MEASURED_TELEMETRY if frames
                else DataProvenance.PLANNED
            ),
            unit="%",
        )
        if not collection_ok:
            failed.append("collection_completion_below_target")

        cov_score = metrics.get("coverage_percent", MetricEntry(actual=100.0, passed=True)).actual
        score = round(0.6 * cov_score + 0.4 * candidate.estimated_remaining_battery_percent, 2)

        return KPIEvaluationResponse(
            route_version=candidate.route_version,
            policy_version=policy.policy_version,
            passed=(len(failed) == 0),
            score=score,
            metrics=metrics,
            failed_constraints=failed,
            recommended_adjustments=recs,
            requires_human_review=human_review,
        )
