"""Backend package for the local AARPES development application."""
